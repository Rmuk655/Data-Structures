#include <iostream>
#include <string>
using namespace std;

class Stack {
    private:
        int s[1000];
        int top, count;
    public:
        Stack();
        void push(int x);
        int pop();
        int size();
};

Stack::Stack() {
    top = -1;
    count = 0;
}

void Stack::push(int x) {
    if (top == 999) {
        cout<<"Stack is full"<<endl;
        return;
    }
    if (top == -1)
        top = 0;
    else    
        top++;
    s[top] = x;
    count++;
    return;
}

int Stack::pop() {
    if (top == -1) {
        cout<<"Stack is Empty"<<endl;
        return -1;
    }
    int x = s[top];
    top--;
    count--;
    return x;
}

int Stack::size() {
    return count;
}

int isOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^')
        return 1;
    return 0;
}

int main() {
    string input;
    getline(cin,input);
    int ans = 0;
    Stack S;
    int i=0;
    while(input[i] != '\0') {
        while(!isOperator(input[i])) {
            S.push(input[i]-'0');
            i++;
        }
        int num1 = S.pop();
        int num2 = S.pop();
        if(input[i] == '+')
            ans=num1+num2;
        else if(input[i] == '-')
            ans=num2-num1;
        else if(input[i] == '*')
            ans=num1*num2;
        else if(input[i] == '/')
            ans=num2/num1;
        else if(input[i] == '^') {
            int temp = 1;
            while(num1 >= 1) {
                temp*=num2;
                num1--;
            }
            ans=temp;
        }
        i++;
        S.push(ans);
    }
    ans = S.pop();
    cout<<ans<<endl;
    cout<<"Thank You...Visit Again!"<<endl;
    return 0;
}

