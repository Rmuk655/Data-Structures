#include <iostream>
using namespace std;

class Queue {
    private:
        int q[1000];
        int front, rear, count;
    public:
        Queue();
        void enqueue(int x);
        int dequeue();
        int size();
        void reverseFirstK(int k);
        void display();
};

Queue::Queue() {
    front = 0;
    rear = -1;
    count = 0;
}

void Queue::enqueue(int x) {
    if (rear == 999) {
        cout<<"Queue is Full"<<endl;
        return;
    }
    rear++;
    q[rear] = x;
    count++;
    return;
}

int Queue::dequeue() {
    if (count == 0) {
        cout<<"Queue is Empty"<<endl;
        return -1;
    }
    int x = q[front];
    front++;
    count--;
    return x;
}

int Queue::size() {
    return count;
}

void Queue::display() {
    for (int i = front; i <= rear; i++)
        cout<<q[i]<<" ";
    cout<<endl;
    return;
}

void reverse(Queue& Q, int k) {
    if (k <= 0 || Q.size()==0)
        return;
    int x = Q.dequeue();
    reverse(Q,k-1);
    Q.enqueue(x);
    return;
}

void circulate(Queue& Q, int k) {
    for (int i = 0;i < Q.size()-k;i++) 
        Q.enqueue(Q.dequeue());
    return;    
}

int main() {
    Queue Q;
    int n, k;
    cin>>n; 
    for (int i = 0;i<n;i++) {
        int x;
        cin>>x;
        Q.enqueue(x);
    }
    cin>>k;
    if(k<0 || k>Q.size()) {
        cout<<"Invalid number of elements to be reversed!"<<endl;
        return 0;
    }
    reverse(Q,k);
    circulate(Q,k);
    Q.display();
    cout<<"Thank You...Visit Again!"<<endl;
    return 0;
}
