#include <iostream>
#include <string>
using namespace std;

class Stack {
    private:
        int s[1000];
        int top, count;
    public:
        Stack();
        void push(int x);
        int pop();
        int size();
};

Stack::Stack() {
    top = -1;
    count = 0;
}

void Stack::push(int x) {
    if (top == 999) {
        cout<<"Stack is full"<<endl;
        return;
    }
    if (top == -1)
        top = 0;
    else    
        top++;
    s[top] = x;
    count++;
    return;
}

int Stack::pop() {
    if (top == -1) {
        cout<<"Stack is Empty"<<endl;
        return -1;
    }
    int x = s[top];
    top--;
    count--;
    return x;
}

int Stack::size() {
    return count;
}

void enqueue(Stack& S, int x) {
    S.push(x);
    return;
}

void dequeue(Stack& S1, Stack& S2) {
    if(S1.size()==0) {
        cout<<"Queue is Empty"<<endl;
        return;
    }
    while (S1.size() > 1)
        S2.push(S1.pop());
    cout<<"Dequeued: "<<S1.pop()<<endl;
    while (S2.size() > 0)
        S1.push(S2.pop());
    return;
}

int main() {
    Stack S1, S2;
    int op;
    cin>>op;
    if (op == 3)
        return 0;
    do {
        switch (op) {
            case 1: 
                int num;
                cin>>num;
                enqueue(S1, num);
                break;
            
            case 2:
                dequeue(S1, S2);
                break;
            
            default:
                break;
        }
        cin>>op;
    } while (op != 3);
    cout<<"Thank You...Visit Again!"<<endl;
    return 0;
}
