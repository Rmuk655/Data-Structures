#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <ctime>
#include <stdexcept>
#define N 1000
#define M 5000
#define P 47055833459LL // A prime number for hashing
using namespace std;

struct Data {  // Stores the input data from the csv file
    long long NHS_No;
    string name;
    string email;
    string gender;
};

struct Table2 {  // Table object for Hash Table in second level 
    Data D;
    int counter;
    Table2() : counter(0) {}
};

struct Table1 {  // Table object for Hash Table in sfirst level 
    int count;
    long long a1;
    long long b1;
    Table1() : count(0), a1(1), b1(0) {}
};

long long hashFunction(long long a, long long b, long long k, int m) {  // Hash Function to implement the Hash Table
    if (m <= 0) {
        cerr<<"Key Not Found"<<endl;
        exit(1);
    }
    long long hash = (a*k + b)%P;
    if (hash < 0) 
        hash+= P;    // Ensure hash to be non-negative, otherwise we go out of bounds
    return hash % m;
}

Data parseLine(const string& line) {
    Data rowData;
    auto start = line.begin();      // Iterators for the start and end of a line
    auto end = line.begin();
    int column = 0;
    while (end != line.end()) {
        while (end != line.end() && *end != ',')
            end++;
        auto cellStart = start;
        while (cellStart != end && isspace(*cellStart))   //Trim all spaces
            cellStart++;
        auto cellEnd = end;
        while (cellEnd != cellStart && isspace(*(cellEnd - 1)))
            cellEnd--;
        string cell(cellStart, cellEnd);
        switch (column) {
            case 0: break; // Serial number in column 0, ignored
            case 1: rowData.NHS_No = stoll(cell); break;
            case 2: rowData.name = cell; break;
            case 3: rowData.email = cell; break;
            case 4: rowData.gender = cell; break;
            default: break;
        }
        if (end != line.end()) {
            start = end + 1;
            ++end;
        }
        column++;
    }
    return rowData;
}

int generate(long long x) {     //Funciton to generate a random number
    return rand() % x;
}

Data search(long long k, long long a, long long b, const vector<Table1>& T, const vector<vector<Table2>>& Tb) {  //Function to search data
    int slot1 = hashFunction(a, b, k, M);
    if (slot1 < 0 || slot1 >= M)  //Used appropriate error handling
        throw out_of_range("Slot1 index out of bounds");
    int slot2 = hashFunction(T[slot1].a1, T[slot1].b1, k, 10 * T[slot1].count * T[slot1].count);
    if (slot1 >= Tb.size() || slot2 >= Tb[slot1].size())
        throw out_of_range("Slot2 index out of bounds");
    return Tb[slot1][slot2].D;
}

int main() {
    srand(time(0));         //Used for random seeding
    ifstream file("data.csv");
    if (!file.is_open()) {
        cerr<<"Failed to open the file."<<endl;
        return 1;
    }
    vector<Data> dataset;
    string line;
    getline(file, line); // Skip the first row
    while (getline(file, line)) {
        Data rowData = parseLine(line);
        dataset.push_back(rowData);
    }
    vector<vector<int>> temp(M);   // A temporary container for the dataset
    vector<Table1> T1(M);          // Object for the first hash table
    long long sum = 0;
    long long a, b;
    do {
        for (int i = 0; i < M; i++)
            T1[i].count = 0;
        a = 1 + generate(P - 1);
        b = generate(P);
        for (int i = 0; i < N; ++i) {
            int slot = hashFunction(a, b, dataset[i].NHS_No, M);
            if (slot >= M || slot < 0) {
                continue; // Skip invalid slots
            }
            temp[slot].push_back(i);
            (T1[slot].count)++;
        }
        sum = 0;
        for (int i = 0; i < M; ++i)
            sum += (long long)(T1[i].count)*(T1[i].count);
    } 
    while (sum > M);
    vector<vector<Table2>> T2(M);    // Actual object for the second hash table
    for (int i = 0; i < M; i++) {
        if (T1[i].count > 0) {
            bool noCollision = false;  
            while (!noCollision) {
                long long size = 10 * T1[i].count * T1[i].count;
                T2[i].resize(size);  // Dynamically reallocating the memory
                for (auto& t : T2[i])
                    t.counter = 0;   // Reset all counters to 0
                T1[i].a1 = 1 + generate(P - 1);
                T1[i].b1 = generate(P);
                noCollision = true;
                for (int j = 0; j < T1[i].count; j++) {
                    int slot = hashFunction(T1[i].a1, T1[i].b1, dataset[temp[i][j]].NHS_No, size);
                    if (slot >= size) {
                        noCollision = false;  // exit if collision found
                        break;
                    }
                    if (T2[i][slot].counter > 0) {
                        noCollision = false;
                        break;
                    }
                    T2[i][slot].counter = 1;
                    T2[i][slot].D = dataset[temp[i][j]];
                }
            }
        }
    }
    long long value;
    cout<<"Enter the NHS_No. to search in the Hash Table: ";
    cin>>value;
    if(value <= 0) {
        cout<<"Key Not Found"<<endl;
        exit(1);
    }
    try {               // Appropriate exception handling
        Data tem = search(value, a, b, T1, T2);
        if(tem.name == "" || tem.email == "" || tem.gender == "") {  //Since these fields cannot be empty, we handle this exception as well
            cerr<<"Key Not Found"<<endl;
            exit(1);
        }
        cout<<"Name: "<<tem.name<<endl<<"Email: "<<tem.email<<endl<<"Gender: "<<tem.gender<<endl;
    }
    catch (out_of_range &e) {
        cerr<<"Exception Encountered: "<<e.what()<<endl;
    }
    file.close();
    return 0;
}