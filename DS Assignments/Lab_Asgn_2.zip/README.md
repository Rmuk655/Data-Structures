# Lab Assignment 2: CS2233 - Report and README

**Author:** Roshan Y Singh  
**Roll Number:** CS23BTECH11052

## Introduction

This report provides an overview of the implementation of a static dictionary using a perfect hashing algorithm. The dataset consists of NHS numbers, names, emails, and gender information for *n = 1000* elements. The goal is to achieve efficient storage and retrieval of these elements, using a perfect hashing approach to ensure constant-time complexity and minimal space usage.

## Problem Description

The challenge is to implement a static dictionary capable of storing and retrieving data associated with NHS numbers. Each element must be uniquely identified by its NHS number, with no collisions allowed. The solution must use a space-efficient approach, ensuring the total space used does not exceed a constant multiple of the number of elements, `cn`, and providing efficient search operations.

## Approach Overview

The solution utilizes a two-level perfect hashing scheme:

- A family of universal hash functions is employed to reduce the likelihood of collisions.
- The first level of hashing maps each key to one of `M = 5n` slots. A hash function is selected to minimize the sum of the squares of the keys mapped to each slot.
- The second level uses separate hash tables for each slot, with tailored hash functions to ensure no collisions within each slot. The size of each secondary table is determined based on the number of keys in the respective slot.

## Detailed Approach Explanation

### Parsing the Input Data

The input consists of a CSV file containing data in the format of NHS number, name, email, and gender. The parsing method reads each line, extracts relevant fields, trims unnecessary whitespace, and stores each piece of data in a structured format. The data is then used to populate the hash tables.

### Hash Function Design

A universal hash function is chosen for both the first and second levels of hashing. This type of function is designed to distribute keys uniformly across the hash table, minimizing the likelihood of collisions. The function parameters are selected by using a random seed generator to optimize performance and ensure that the hash values are within the desired range.

Currently, the hash function chosen is similar to the form of:

h{a,b}(k) = ((a * k + b) MOD P) MOD M 

However, we use an even more modified version, which is given as:

h{a,b}(k) = (((a * k + b) MOD P + P) MOD P) MOD M

Here, we choose `P` to be a large prime number (47055833459 in our case). The reason to use the second equation and not the first one directly is to ensure that by adding `P` (the part where we do `+ P` and then take the remainder), we can ensure that the hash function returns a positive value even for the type `long long int`, where it may warp back to a negative slot while simply taking the remainder.

### First-Level Hash Table Construction

The first level of the hash table aims to map NHS numbers to `M = 5n` slots. If the sum of squares of the number of keys assigned to each slot exceeds a threshold (in this case, `M`), indicating too many collisions, a new hash function is selected. This process ensures that the load distribution among the slots is balanced, which is crucial for minimizing space and ensuring efficient access. In the first-level hash table, we store an array of tables. Here, each table consists of the count of the number of rows of the dataset that match with this particular slot, along with the hash function parameters to find the correct slot for the key in the second-level hash table, which are 'a' and 'b' parameters from the given hash function.

### Second-Level Hash Table Construction

For each slot in the first-level hash table that contains keys, a second-level hash table is created. The size of this table is proportional to the square of the number of keys in the slot (10 times the square of the number of keys, to be precise), ensuring enough space to resolve any collisions. A second-level hash function is then chosen to map the keys within this slot without any collisions, guaranteeing that each key has a unique position in its respective secondary table. The second-level hash table consists of an array of tables for each slot in the first hash table, where each table contains a counter (that is used to ensure there are no collisions), and a structure that stores the actual 'Data' which corresponds to the key.

### Search Function

The search operation involves using the first-level hash function to locate the appropriate slot in the first hash table. Through this slot, we access the appropriate parameters for the second hash function. We then use our second-level hash function to find the exact position of the key within the secondary table. This two-step process ensures that searches are both fast and reliable, taking constant time due to the perfect hashing structure.

Thus, we have: **Time Complexity of Search = O(1)**

### Exception Handling

Simple error handling mechanisms are implemented to manage scenarios such as out-of-bounds access and missing keys. By catching and handling exceptions, the program maintains stability and prevents crashes, ensuring that all operations are performed smoothly and that users are informed of any issues.

## Complexity Analysis

The perfect hashing algorithm ensures that both the search time and space complexity are efficient. By carefully selecting hash functions and managing collisions, the algorithm achieves `O(1)` time complexity for search operations. The space complexity is `O(n)`, proportional to the number of elements, ensuring that the space used remains within acceptable bounds. Note that this part has already been informed in the problem statement, where it is said that: "The space required to store the elements should be at most cn, for some constant c", thus ensuring that the space complexity is overall `O(n)`.

## Conclusion

The implemented perfect hashing algorithm effectively addresses the problem of constructing a static dictionary for the given dataset. By employing a two-level hashing scheme, it ensures constant-time search operations and optimal space usage. The approach successfully handles potential collisions and provides robust error handling, making it a reliable solution for the static dictionary problem.

## README Instructions

### Downloading and Running the `Hash.cpp` Code

#### Step 1: Download the Code

1. Download the `CS23BTECH11052.zip` file containing the `Hash.cpp` source code.
2. Extract the `CS23BTECH11052.zip` file to a directory of your choice.

#### Step 2: Install `g++` Compiler

If you haven't already installed the `g++` compiler, you can do so by using the following commands based on your operating system:

- **For Ubuntu/Linux:**
  ```bash
  sudo apt-get update
  sudo apt-get install g++
  '''
  
- **For macOS:**

    ```bash
    xcode-select --install
    ```

- **For Windows:**

    - You can install `g++` by downloading [MinGW](https://sourceforge.net/projects/mingw/). Follow the installation instructions on the MinGW website to set up `g++`.

### Step 3: Compile the Code

Navigate to the directory where you extracted the `CS23BTECH11052.zip` file and run the following command in the terminal to compile `Hash.cpp`:

```bash
g++ Hash.cpp -o Hash

Here, `-o Hash` specifies that the output executable will be named `Hash`. You can replace `Hash` with any other name if you prefer.

### Step 4: Run the Executable

After successfully compiling the code, run the executable by typing:

```bash
./Hash

### Step 5: Use the Program

The program will prompt you to enter an NHS number. Simply enter the required NHS number to search, and the corresponding data will be output on the terminal.

### Libraries/Include Files Used

The following standard C++ library headers are used in the `Hash.cpp` code:

- `<iostream>`
- `<string>`
- `<fstream>`
- `<vector>`
- `<ctime>`
- `<stdexcept>`

These headers are pre-installed with `g++` and do not require any additional installation.


This Markdown text includes explanations for running the executable, using the program, and the standard C++ libraries used in the `Hash.cpp` code.


