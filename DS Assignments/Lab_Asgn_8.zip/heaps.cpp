#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

class MinHeap {
    private:
        vector<int> heap;

    public:
        void swap(int &x, int &y) { // Function to swap two elements
            int temp = x;
            x = y;
            y = temp;
            return;
        }

        void buildHeap() {  // Function to build the heap in O(n) time
            for(int i = (heap.size()/2) - 1;i>=0;i--)
                heapify(i,heap.size()); // Continuosly call heapify
            return;
        }

        void heapify(int i, int size) { // Function to heapify a subtree rooted at index i, size is the current size of the heap
            int smallest = i;
            int l = 2*i+1;
            int r = 2*i+2;
            if(l<size && heap[l]<heap[smallest])
                smallest = l;
            if(r<size && heap[r]<heap[smallest])
                smallest = r;
            if(smallest != i) {
                swap(heap[i],heap[smallest]);
                heapify(smallest,size);
            }
            return;
        }

        int deleteMin() {
            if(heap.empty())
                throw runtime_error("Heap underflow");
            int min = heap[0];  // Minimum value is the root
            heap[0] = heap[heap.size()-1];
            heap.pop_back();    // Remove the last element
            if(!heap.empty())
                heapify(0,heap.size());
            return min;
        }

        void heapSort() {   // Function to perform heap sort in O(nlogn) time
            buildHeap();
            int ele = heap.size();  // Store the original size of the heap
            for(int i=ele-1;i>0;i--) {
                swap(heap[0],heap[i]); // Move the current smallest element (heap[0]) to the end
                heapify(0,i);// Heapify the reduced heap (from index 0 to i-1)
            }
            return;
        }

        MinHeap(const vector<int> &arr) : heap(arr) {}  // Constructor to initialize the heap with input array

        void displayHeap() {  // Function to display the heap
            for(int i=0;i<heap.size()/2;i++)    // In the end of the mehtods, we have a max-heap, to make it into a sorted min-heap, we reverse
                swap(heap[i],heap[heap.size()-i-1]);
            for(int num : heap)
                cout<<num<<" ";
            cout<<endl;
            return;
        }
};

int main() {
    string input;
    vector<int> nums;
    getline(cin, input);
    if(input == "")
        cout<<endl;
    for(int i=0;i<input.size();i++) {
        if(input[i] != ',' && input[i] != ' ') {
            int sign = 1, num = 0;
            if(input[i] == '-') {
                sign = -1;  // Handle negative numbers
                i++;
            }
            while(i<input.size() && input[i] != ',' && input[i] != ' ') {
                num = num*10 + (input[i]-'0'); // Accumulate digits
                i++;
            }
            nums.push_back(sign*num); // Append parsed number
            i--;
        }
    }
    MinHeap H(nums);
    H.heapSort(); // Sort the heap in place
    cout<<"Sorted array: ";
    H.displayHeap(); // Display the sorted heap
    return 0;
}
