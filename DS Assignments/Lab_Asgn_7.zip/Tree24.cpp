#include <iostream>
#include <vector>

using namespace std;

class Tree24 {
    public:
        struct Node {
            int data[3];       
            Node* child[4];    
            Node* parent;      

            Node() {
                for(int i = 0; i < 3; i++) {
                    data[i] = INT32_MIN;    // Initialize with dummy values
                    child[i] = nullptr;
                }
                child[3] = nullptr;  
                parent = nullptr;  
            }
        };

        Tree24() {
            root = nullptr;
        }

        ~Tree24() {}

        Node* getRoot() {
            return root;
        }

        Node* search(Node* node,int key){
            if(node == nullptr)
                return nullptr;
            for(int i=0;i<3;i++){
                if(node->data[i] == key)
                    return node;   // This means key has been found
            }
            if(node->data[0] != INT32_MIN && node->data[0] > key)   // Check all possible cases, and continue recursively
                return search(node->child[0],key);
            else if(node->data[1] == INT32_MIN)
                return search(node->child[1],key);
            else if(node->data[1] != INT32_MIN && node->data[1] > key)
                return search(node->child[1],key);
            else if(node->data[2] == INT32_MIN)
                return search(node->child[2],key);
            else if(node->data[2] != INT32_MIN && node->data[2] > key)
                return search(node->child[2],key);
            else if(node->data[2] != INT32_MIN && node->data[2] < key)
                return search(node->child[3],key);
            return nullptr;     // Search was unsuccessfull
        }

        int findIndex(int data[], int key, int size) {      // Helper function to find the index for the given key
            int i = 0;
            while(i<size && data[i] != INT32_MIN && data[i]<key)
                i++;
            return i;
        }

        void split(Node* node, int& key, Node*& newChild) { // Splitting a full node
            Node* newNode = new Node();     // Split data into two parts and middle key is pushed up
            int mid = 1;
            newNode->data[0] = node->data[2]; 
            newNode->child[0] = node->child[2];
            newNode->child[1] = node->child[3];
            if(newNode->child[0] != nullptr)
                newNode->child[0]->parent = newNode;
            if(newNode->child[1] != nullptr)
                newNode->child[1]->parent = newNode;
            node->data[2] = INT32_MIN;       // Remove the third key from original node
            node->child[2] = nullptr;
            node->child[3] = nullptr;
            key = node->data[mid];      // Middle key to be pushed up
            node->data[mid] = INT32_MIN;
            newChild = newNode;     // Set the new node as the right child after splitting
        }

        void insert(int key) {  // Insert function for the general case
            if(search(root,key) != nullptr) {
                cout<<key<<" already present. So no need to insert"<<endl;
                return;
            }
            cout<<key<<" inserted"<<endl;
            if(root == nullptr) {
                root = new Node();
                root->data[0] = key;
                return;
            }
            if(root->data[2] != INT32_MIN) {   // If the root is full, we split the root and increase the tree height
                Node* newNode = new Node();
                int mid;
                Node* newChild;
                split(root,mid,newChild);
                newNode->data[0] = mid;
                newNode->child[0] = root;
                newNode->child[1] = newChild;
                root->parent = newNode;
                if(newChild != nullptr)
                    newChild->parent = newNode;
                root = newNode;  // New root becomes the parent of the split node
            }
            insertEasy(root,key);    // Insert the key into the non-full root
        }

        void insertEasy(Node* node, int key) {  // Function to handle insertion into non-full node case
            int index = findIndex(node->data,key,3);
            if(node->child[0] == nullptr) {        // If node is a leaf, insert key directly into it
                for(int i=2;i>=index;i--) {
                    if(node->data[i] != INT32_MIN)
                        node->data[i+1] = node->data[i];
                }
                node->data[index] = key;
            }
            else{   
                Node* child = node->child[index];       // Case when it is an internal node
                if(child->data[2] != INT32_MIN) {       // If child is full, split it
                    int mid;
                    Node* newChild;
                    split(child,mid,newChild);
                    for(int i=2;i>=index;i--) {  // Insert the middle key into the current node
                        if(node->data[i] != INT32_MIN) {
                            node->data[i+1] = node->data[i];
                            node->child[i+2] = node->child[i+1];
                        }
                    }
                    node->data[index] = mid;
                    node->child[index+1] = newChild;
                    if (key > node->data[index])      // After splitting, insert the key at the right position
                        index++;
                }
                insertEasy(node->child[index],key);
            }
            return;
        }

        void levelOrder(Node* root) {   // Level-order traversal to display the tree
            if(root == nullptr) {
                cout<<"Tree is empty"<<endl;
                return;
            }
            vector<Node*> nodes;    // Behaves like a queue of nodes
            nodes.push_back(root);
            int index = 0;
            while(index < nodes.size()) {
                int size = nodes.size() - index;
                for(int i=0;i<size;i++) {
                    Node* node = nodes[index];
                    index++;
                    cout<<"(";      // To print the nodes in a more clear format
                    bool first = true;
                    for(int j=0;j<3;j++) {
                        if(node->data[j] != INT32_MIN) {
                            if(!first)
                                cout<<" ";
                            first = false;
                            cout<<node->data[j];
                        }
                    }
                    cout<<")";
                    for(int j=0;j<4;j++) {
                        if(node->child[j] != nullptr)
                            nodes.push_back(node->child[j]);
                    }
                    cout<<" ";
                }
                cout<<endl;     // Move to the next level
            }
        }

    private:
        Node* root;
};

int main() {
    Tree24 T;
    T.insert(32);   // These are inserted as default as it is asked in the problem statement
    T.insert(56);
    T.insert(21);
    T.insert(90);
    cout<<"Note that 32, 56, 21 and 90 will be present as default in the tree already, since this was mentioned in the problem statement. Please give the number of keys and the keys to insert next"<<endl;
    int n;
    cin>>n;
    for(int i=0;i<n;i++) {
        int key;
        cin>>key;
        T.insert(key);
    }
    int op;
    cout<<"Queries - Each line contains 2 integers separated by space character. First integer for type of query:"<<endl;
    cout<<"1 for search"<<endl<<"2 for insert"<<endl<<"3 for delete (Note that deletion has not been implemented as a part of this program)"<<endl;
    cout<<"4 for displaying the tree in level order."<<endl<<"5 for exiting"<<endl;
    cout<<"Enter the operation: "<<endl;
    do {
        int key;
        cin>>op;
        if(op==1) {
            cin>>key;
            if(T.search(T.getRoot(),key) == nullptr)
                cout<<key<<" not present"<<endl;
            else
                cout<<key<<" present"<<endl;
        }
        else if(op==2) {
            cin>>key;
            T.insert(key);
        }
        else if(op==3) {
            cin>>key;
            cout<<"Deletion has not been implemented as a part of this program!"<<endl;
        }
        else if(op==4) {
            cout<<"Level Order Traversal:"<<endl;
            T.levelOrder(T.getRoot());
        }
        else if(op==5)
            cout<<"Thank You! Visit Again..."<<endl;    // Additional command to exit the program
        else
            cout<<"Please enter a valid operation!"<<endl;
    }
    while(op!=5);
    return 0;
}

