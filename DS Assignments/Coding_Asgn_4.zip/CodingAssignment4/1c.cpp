#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool solve(int n, vector<vector<int>>& adj) {   // Function to check if the graph is bipartit
    vector<int> colour(n,-1); // Colour array to store the colour of each vertex (-1 means uncoloured)
    for(int start = 0;start < n;start++) {
        if(colour[start] != -1) 
            continue; // Skip already coloured components
        queue<int> q;
        q.push(start);
        colour[start] = 0; // Start colouring with 0
        while(!q.empty()) {
            int u = q.front();
            q.pop();
            for(int v : adj[u]) {   // Check all adjacent vertices
                if(colour[v] == -1) {
                    colour[v] = 1-colour[u];    // colour with the opposite colour of `u`
                    q.push(v);
                }
                else if(colour[v] == colour[u]) {   // If a neighbour has the same colour, the graph is not bipartite
                    return false;
                }
            }
        }
    }
    return true;    // All components checked, and no conflicts found
}

int main() {
    int n,m;
    cin>>n>>m;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    vector<vector<int>> adj(n); // Adjacency list to represent the graph
    for(int i=0;i<m;i++) {
        int a,b;
        cin>>a>>b;
        adj[a].push_back(b);    // Add b to a's adjacency list and vice-versa
        adj[b].push_back(a);
    }
    if(solve(n,adj))    
        cout<<"YES"<<endl;  // Output "YES" if bipartite
    else
        cout<<"NO"<<endl;
    return 0;
}
