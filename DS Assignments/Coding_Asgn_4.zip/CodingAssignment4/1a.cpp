#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;

void pathPrint(int &v, int &s, vector<int> &Length,vector<int> &parent){    // Output the paths and lengths for a given vertex
    if(v==s)    // Base case: if the current vertex is the source, return
        return;
    if(Length[v] == -1) {   // If the vertex is not reachable
    cout<<"No path to "<<v<<endl;
    return;
    }
    vector<int> path;   // To store the path from source to current vertex
    for(int cur = v;cur!= -1;cur = parent[cur]) // Traverse back using the parent array
        path.push_back(cur);
    reverse(path.begin(),path.end());   // Reverse the path to get the correct order
    for(int node : path)
        cout<<node<<" ";
    cout<<Length[v]<<endl;  // Print the length of the path
    return;
}

void dfs(int n, vector<vector<int>>& adj, int s) {  // Depth First Search to explore paths and lengths from the source vertex
    vector<bool> visited(n,false);  // To keep track of visited vertices
    vector<int> parent(n,-1);   // To store the parent of each vertex for path reconstruction
    vector<int> Length(n,-1);   // To store the length of the path from source to each vertex
    stack<int> stk;  // Stack for DFS traversal
    stk.push(s);
    visited[s] = true;  // Mark the source as visited
    Length[s] = 0;
    while(!stk.empty()) {   // Process vertices while the stack is not empty
        int u = stk.top();
        stk.pop();
        if(!visited[u]){    // If the vertex is encountered for the first time
            pathPrint(u,s,Length,parent);   // Print the path and its length
        }
        for(int i = adj[u].size()-1;i>=0;i--) {     // Explore all neighbors of the current vertex in reverse order
            int v = adj[u][i];
            if(!visited[v]) {   // If the neighbor is not visited
                parent[v] = u;
                Length[v] = Length[u] + 1;  // Update the length of the path
                stk.push(v);    // Push the neighbor onto the stack
            }
        }
        visited[u] = true;  // Mark the current vertex as visited
    }
}

int main() {
    int n,m,s;
    cin>>n>>m>>s;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    if(s<0) {
    	cout<<"Invalid source"<<endl;
    	return 0;
    }
    vector<vector<int>> adj(n); // Adjacency list to store the graph
    for(int i=0;i<m;i++) {
        int a,b;
        cin>>a>>b;
        adj[a].push_back(b);    // Add b to the adjacency list of a and vice-versa
        adj[b].push_back(a);
    }
    dfs(n,adj,s);   // Perform DFS from the source vertex
    return 0;
}
