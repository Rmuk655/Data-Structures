#include <iostream>
#include <vector>
#include <queue>
#include <climits>
using namespace std;

void dijkstra(int n, int m, int s, vector<vector<pair<int, int>>>& adj) {   // Function to implement Dijkstra's Algorithm
    vector<int> dist(n,INT_MAX); // Stores shortest path distances
    vector<int> parent(n,-1);   // To reconstruct the shortest path
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<>> pq;   // Min-heap for shortest distance
    dist[s] = 0;
    pq.push({0,s});      // Push the source vertex with distance 0
    while(!pq.empty()) {       // Process the priority queue
        auto [d,u] = pq.top();  // Get the vertex with the smallest distance
        pq.pop();
        if(d > dist[u])     // Ignore previous entries in the priority queue
            continue;
        for(auto [v,w] : adj[u]) {  // Relaxation step for all adjacent vertices
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;  // Update the shortest distance
                parent[v] = u;
                pq.push({dist[v],v});   // Push updated distance to priority queue
            }
        }
    }
    for(int v = 0;v<n;v++) {    // Output the shortest paths from the source to all other vertices
        if(v == s) 
            continue; // Skip source vertex
        if(dist[v] == INT_MAX)
            cout<<s<<" -> "<<v<<" no path exists"<<endl;
        else{
            cout<<s<<" -> "<<v<<" path length = "<<dist[v]<<" path = [";
            vector<int> path;
            for(int x=v;x!= -1;x = parent[x])   // Reconstruct the path using the parent array
                path.push_back(x);
            for(int i = path.size()-1;i>=0;i--) {        // Print the path in reverse order
                cout<<path[i];
                if(i>0) 
                    cout<<", ";
            }
            cout<<"]"<<endl;
        }
    }
}

int main() {
    int n,m,s;
    cin>>n>>m>>s;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    if(s<0) {
    	cout<<"Invalid source"<<endl;
    	return 0;
    }
    vector<vector<pair<int,int>>> adj(n);   // Adjacency list to store graph edges
    for (int i=0;i<m;i++) {
        int a,b,w;
        cin>>a>>b>>w;
        adj[a].push_back({b,w});    // Add the directed edge to adjacency list
    }
    dijkstra(n,m,s,adj);    // Run Dijkstra's algorithm
    return 0;
}
