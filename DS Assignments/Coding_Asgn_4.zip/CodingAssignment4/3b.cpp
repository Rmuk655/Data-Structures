#include <iostream>
#include <vector>
#include <climits>
#include <tuple>
using namespace std;

void ford(int n, int m, int s, vector<tuple<int,int,int>>& edges) {     // Function to perform the Bellman-Ford algorithm
    vector<int> dist(n,INT_MAX);    // Initialize distances to all vertices as infinity
    vector<int> parent(n,-1);    // To reconstruct the shortest path
    dist[s] = 0;        // Distance to the source vertex is 0
    for(int i = 0;i<n-1;i++) {      // Relax edges V - 1 times
        for(auto [u,v,w] : edges) {
            if(dist[u] != INT_MAX && dist[u]+w < dist[v]) {
                dist[v] = dist[u] + w;  // Update the shortest distance to v and parent of v
                parent[v] = u;
            }
        }
    }
    for(auto [u,v,w] : edges) {     // One extra repetition for negative-weight cycles
        if(dist[u] != INT_MAX && dist[u]+w < dist[v]) {
            cout << "Contains negative cycle" << endl;
            return;     // Exit if a negative-weight cycle is detected
        }
    }
    for(int v=0;v<n;v++) {      // Output the shortest paths from the source vertex
        if(v == s) 
            continue;       // Skip source vertex
        if(dist[v] == INT_MAX)
            cout<<s<<" -> "<<v<<" no path exists"<<endl;
        else{
            cout<<s<<" -> "<<v<<" path length = "<<dist[v]<<" path = [";
            vector<int> path;
            for(int x=v;x!= -1;x = parent[x])   // Reconstruct the path using the parent array
                path.push_back(x);
            for(int i = path.size()-1;i>=0;i--) {       // Print the path in reverse order
                cout<<path[i];
                if(i>0) 
                    cout<<", ";
            }
            cout<<"]"<<endl;
        }
    }
}

int main() {
    int n,m,s;
    cin>>n>>m>>s;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    if(s<0) {
    	cout<<"Invalid source"<<endl;
    	return 0;
    }
    vector<tuple<int,int,int>> edges;   // Edge list to store the graph
    for(int i=0;i<m;i++) {
        int a,b,w;
        cin>>a>>b>>w;
        edges.push_back({a,b,w});   // Add the directed edge to the edge list
    }
    ford(n,m,s,edges);    // Run the Bellman-Ford algorithm
    return 0;
}
