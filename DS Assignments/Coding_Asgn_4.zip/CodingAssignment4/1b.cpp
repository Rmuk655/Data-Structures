#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

void pathPrint(int &v, int &s, vector<int> &Length,vector<int> &parent){    // Output the paths and lengths for a given vertex
    if(v==s)    // Base case: if the current vertex is the source, return
        return;
    if(Length[v] == -1) {   // If the vertex is not reachable
    cout<<"No path to "<<v<<endl;
    return;
    }
    vector<int> path;   // To store the path from source to current vertex
    for(int cur = v;cur!= -1;cur = parent[cur]) // Traverse back using the parent array
        path.push_back(cur);
    reverse(path.begin(),path.end());   // Reverse the path to get the correct order
    for(int node : path)
        cout<<node<<" ";
    cout<<Length[v]<<endl;  // Print the length of the path
    return;
}

void bfs(int n, vector<vector<int>>& adj, int s) {  // Breadth First Search to explore paths and lengths from the source vertex
    vector<bool> visited(n,false);  // To keep track of visited vertices
    vector<int> parent(n,-1);   // To store the parent of each vertex for path reconstruction
    vector<int> Length(n,-1);   // To store the length of the path from source to each vertex
    queue<int> q;   // Queue for BFS traversal
    q.push(s);
    visited[s] = true;  // Mark the source as visited
    Length[s] = 0;
    while(!q.empty()) { // Process vertices while the queue is not empty
        int u = q.front();
        q.pop();
        pathPrint(u,s,Length,parent);
        for(int v : adj[u]) {   // Explore all neighbors of the current vertex
            if(!visited[v]) {
                visited[v] = true;  // Mark the neighbor as visited
                parent[v] = u;
                Length[v] = Length[u] + 1;  // Update the length of the path
                q.push(v);   // Enqueue the neighbor
            }
        }
    }
}

int main() {
    int n,m,s;
    cin>>n>>m>>s;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    if(s<0) {
    	cout<<"Invalid source"<<endl;
    	return 0;
    }
    vector<vector<int>> adj(n); // Adjacency list to store the graph
    for(int i=0;i<m;i++) {
        int a,b;
        cin>>a>>b;
        adj[a].push_back(b);     // Add b to the adjacency list of a and vice-versa
        adj[b].push_back(a);
    }
    bfs(n,adj,s);    // Perform BFS from the source vertex
    return 0;
}
