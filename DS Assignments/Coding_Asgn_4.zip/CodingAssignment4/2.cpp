#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Edge {   // Edge structure for Kruskal's Algorithm
    int u,v,w;
    bool operator <(Edge& other) {  // Overload < for sorting by weight
        return w < other.w;
    }
};

void prim(int n, vector<vector<pair<int,int>>>& adj, int s) {   // Function to implement Prim's Algorithm
    vector<bool> inMST(n,false);    // Track vertices already included in MST
    vector<pair<int,int>> mstEdges;     // Edges in the MST
    int total = 0;       // Total weight of MST
    priority_queue<pair<int,pair<int,int>>,vector<pair<int,pair<int,int>>>,greater<>> pq;   // Priority queue or Heap
    pq.push({0,{s,-1}}); // {weight, {current, parent}}
    while(!pq.empty() && mstEdges.size() < n-1) {
        auto [weight,edge] = pq.top();
        pq.pop();
        int u = edge.first,parent = edge.second;
        if(inMST[u]) 
            continue;   // Skip if already in MST
        inMST[u] = true; // Mark as included
        total += weight; // Add weight to total MST weight
        if(parent != -1) 
            mstEdges.push_back({parent,u});
        for(auto [v,w] : adj[u]) {  // Explore adjacent vertices
            if(!inMST[v]) {
                pq.push({w,{v,u}});
            }
        }
    }
    cout<<"Prim's Algorithm"<<endl;     // Print MST edges and total weight
    for(auto [u,v] : mstEdges)
        cout<<u<<" "<<v<<endl;
    cout<<total<<endl;
}

int Find(int u, vector<int>& parent) {  // Find function with path compression for Kruskal's algorithm
    if(u != parent[u]) 
        parent[u] = Find(parent[u],parent);     // Path compression
    return parent[u];
}

void Union(int u, int v, vector<int>& parent, vector<int>& rank) {  // Union function with rank optimization for Kruskal's algorithm
    int rootU = Find(u,parent);     // Find the roots of union-find having u and v
    int rootV = Find(v,parent);
    if(rootU != rootV) {    // Check each case possible for u and v's roots
        if(rank[rootU] > rank[rootV]) {     // Set parent of V's root to U's root
            parent[rootV] = rootU;
        }
        else if(rank[rootU] < rank[rootV]) {    // Set parent of U's root to V's root
            parent[rootU] = rootV;  
        }
        else{
            parent[rootV] = rootU;  // Set parent of V's root to U's root and increment U's union-find structure's rank
            rank[rootU]++;
        }
    }
}

void kruskal(int n, vector<Edge>& edges) {      // Function to implement Prim's Algorithm
    sort(edges.begin(),edges.end());    // Sort edges by weight
    vector<int> parent(n),rank(n,0); // Union-Find structures
    vector<pair<int,int>> mstEdges;  // Edges in the MST
    int total = 0;                    // Total weight of MST
    for(int i=0;i<n;i++)
        parent[i] = i;      // Initialize Union-Find parent array
    for(auto& edge : edges) {
        if(Find(edge.u,parent) != Find(edge.v,parent)) {    // If adding the edge doesn't form a cycle
            mstEdges.push_back({edge.u,edge.v});
            total += edge.w;        // Add weight to total MST weight
            Union(edge.u,edge.v,parent,rank);   // Union the sets
            if(mstEdges.size() == n-1) 
                break;   // Stop when MST is complete
        }
    }
    cout<<"Kruskal's Algorithm"<<endl;    // Print MST edges and total weight
    for(auto [u,v] : mstEdges)
        cout<<u<<" "<<v<<endl;
    cout<<total<<endl;
}

int main() {
    int n,m,s;
    cin>>n>>m>>s;
    if(n<=0 || m<0) {
    	cout<<endl;
        return 0;
    }
    if(s<0) {
    	cout<<"Invalid source"<<endl;
    	return 0;
    }
    vector<vector<pair<int,int>>> adj(n); // adjacency list for Prim's
    vector<Edge> edges;                   // edge list for Kruskal's
    for(int i=0;i<m;i++) {
        int a,b,w;
        cin>>a>>b>>w;
        adj[a].push_back({b,w});    // Add to adjacency list as required and vice-versa
        adj[b].push_back({a,w});
        edges.push_back({a,b,w});
    }
    prim(n,adj,s);  // Run Prim's Algorithm
    kruskal(n,edges);   // Run Kruskal's Algorithm
    return 0;
}
