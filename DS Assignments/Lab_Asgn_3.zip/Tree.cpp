#include <iostream>
#include <vector>
using namespace std;

class Tree {
    public:
        struct Node {        // A node structure with pointers to left and right children. This is the basic unit of the Tree
            int data;
            Node* left;
            Node* right;
            Node(int x) {
                data = x;
                left = nullptr;
                right = nullptr;
            }
        };

        Tree() {            // A simple default constructor for the tree
            root = nullptr;
        }

        Tree(int key) {     // A parameterized constructor using the createNode functions
            root = createNode(key);
        }

        ~Tree() {}  // A simple destructor to clean-up memory of the Tree object

        Node* createNode(int key) {   // Creates a new node with the given key value to be inserted into the tree
            return new Node(key);
        }

        void insertLeft(Node* root, int key) {  // Creates a new node with the given value and inserts it as the left child of a given node
            root->left = createNode(key);
        }

        void insertRight(Node* root, int key) {  // Creates a new node with the given value and inserts it as the right child of a given node
            root->right = createNode(key);
        }

        void preOrder(Node* root) {   // A function to print the tree recursively using pre-order traversal
            if (root == nullptr) 
                return;
            cout<<root->data<<" ";
            preOrder(root->left);
            preOrder(root->right);
        }

        void inOrder(Node* root) {   // A function to print the tree recursively using in-order traversal
            if (root == nullptr) 
                return;
            inOrder(root->left);
            cout<<root->data<<" ";
            inOrder(root->right);
        }

        void postOrder(Node* root) {  // A function to print the tree recursively using post-order traversal
            if (root == nullptr) 
                return;
            postOrder(root->left);
            postOrder(root->right);
            cout<<root->data<<" ";
        }

        int findIndex(const vector<int>& inorder,int beg,int end,int val) {   // Function to find the index of the root in the inorder array
            for (int i=beg;i<=end;i++) {
                if (inorder[i] == val)
                    return i;
            }
            return -1; // This case won't occur because the input is assumed to be correct
        }

        Node* getTree(const vector<int>& inorder,const vector<int>& preorder,int beg,int end,int& index) {  // Function to build tree from inorder and preorder traversals
            if (beg > end) 
                return nullptr;
            int num = preorder[index++];  // Get root value from preorder and store it in num
            Node* root = createNode(num);
            int rootIndex = findIndex(inorder,beg,end,num); // Find the index of root in inorder traversal
            root->left = getTree(inorder,preorder,beg,rootIndex-1,index);
            root->right = getTree(inorder,preorder,rootIndex+1,end,index);
            return root;
        }

        Node* buildTree(const vector<int>& inorder, const vector<int>& preorder) { // Reconstruct tree from inorder and preorder arrays
            int preIndex = 0;
            return getTree(inorder,preorder,0,inorder.size()-1,preIndex);
        }
    
    private:
        Node* root;

};

int main() {
    int k;  // Number of test cases
    cin>>k;
    while(k--){
        int n; 
        cin>>n;
        vector<int> preorder(n),inorder(n);
        for (int i=0;i<n;i++)
            cin>>preorder[i];
        for (int i=0;i<n;i++)
            cin>>inorder[i];
        Tree T;
        Tree::Node* root = T.buildTree(inorder,preorder);  // Build the tree from the given traversal orders and 'root' is the pointer to the root node of this tree
        T.preOrder(root);  // Print or output the tree structure
        cout<<endl;
        T.postOrder(root);
        cout<<endl;
        T.inOrder(root);
        cout<<endl;
    }
    return 0;
}