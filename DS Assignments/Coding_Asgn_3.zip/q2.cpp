#include <iostream>
#include <stdexcept>
using namespace std;

class RBTree {
    public:
        struct Node {
            int data;
            int size;  // Size of subtree rooted at this node, including itself
            Node* left;
            Node* right;
            Node* parent;
            bool color;  // 0 for red, 1 for black

            Node(int x) : data(x), size(1), left(nullptr), right(nullptr), parent(nullptr), color(0) {}  // New nodes are red by default
        };

        RBTree() {  // Constructor to initialize the Red-Black Tree with a sentinel node
            nil = new Node(0);  
            nil->color = 1;    // Sentinel node is always black
            nil->size = 0;     // Sentinel node has size zero
            root = nil;
        }

        ~RBTree() {}    // Simple destructor

        Node* leftRotate(Node* x) { // Function to perform a left rotation on a node
            Node* y = x->right;
            x->right = y->left;     // Turn y's left subtree into x's right subtree
            if(y->left != nil)
                y->left->parent = x;
            y->parent = x->parent;  // Link x's parent to y
            if(x->parent == nil)
                root = y;
            else if(x == x->parent->left)
                x->parent->left = y;
            else
                x->parent->right = y;
            y->left = x;        // Place x on y's left
            x->parent = y;
            y->size = x->size;  // Update sizes after rotation
            x->size = x->left->size + x->right->size + 1;
            return y;
        }

        Node* rightRotate(Node* y) {    // Function to perform a right rotation on a node
            Node* x = y->left;
            y->left = x->right;     // Turn x's right subtree into y's left subtree
            if(x->right != nil)
                x->right->parent = y;
            x->parent = y->parent;  // Link y's parent to x
            if(y->parent == nil)
                root = x;
            else if(y == y->parent->right)
                y->parent->right = x;
            else
                y->parent->left = x;
            x->right = y;       // Place y on x's right
            y->parent = x;
            x->size = y->size;  // Update sizes after rotation
            y->size = y->left->size + y->right->size + 1;
            return x;
        }

        Node* insert(Node* z) { // Insert function to add a node to the Red-Black Tree
            Node* y = nil;      // Parent of the node to be inserted
            Node* x = root;
            while(x != nil) {   // Simple BST insertion
                y = x;
                y->size++;      // Update size for each ancestor node
                x = (z->data < x->data) ? x->left : x->right;
            }
            z->parent = y;
            if(y == nil)
                root = z;
            else if(z->data < y->data)
                y->left = z;
            else
                y->right = z;
            z->left = z->right = nil;
            z->color = 0;       // New node is red by default
            return fixInsert(z);    // Correcting the properties of red black tree
        }

        Node* fixInsert(Node* z) {  // Fixes Red-Black Tree properties after insertion
            while(z->parent->color == 0) {  // Loop until parent is black
                if(z->parent == z->parent->parent->left) {
                    Node* y = z->parent->parent->right;
                    if(y->color == 0) {     // In case y is red
                        z->parent->color = 1;
                        y->color = 1;
                        z->parent->parent->color = 0;
                        z = z->parent->parent;
                    }
                    else{   // Case where y is black
                        if(z == z->parent->right) {
                            z = z->parent;
                            leftRotate(z);
                        }
                        z->parent->color = 1;
                        z->parent->parent->color = 0;
                        rightRotate(z->parent->parent);
                    }
                }
                else{   // Symmetric cases for right child
                    Node* y = z->parent->parent->left;
                    if(y->color == 0) {
                        z->parent->color = 1;
                        y->color = 1;
                        z->parent->parent->color = 0;
                        z = z->parent->parent;
                    }
                    else{
                        if(z == z->parent->left) {
                            z = z->parent;
                            rightRotate(z);
                        }
                        z->parent->color = 1;
                        z->parent->parent->color = 0;
                        leftRotate(z->parent->parent);
                    }
                }
            }
            root->color = 1;    // Root is always black
            return z;
        }

        // Function to search for a node with a given key
        Node* search(Node* node, int key) {
            if(node == nil) 
                throw runtime_error(" key not found");
            if(key == node->data)
                return node;
            else if(key < node->data) {
                return search(node->left,key);
            }
            else
                return search(node->right,key);
        }

        // Function to delete a node with a given key
        void deleteNode(int key) {
            Node* z = search(root,key);
            Node* y = z, *x;
            int originalColor = y->color;   // Store the original color of the node to be deleted
            if(z->left == nil) {    // Continue with simple BST deletion
                x = z->right;
                swap(z, z->right);
            }
            else if(z->right == nil) {  // z has no right child
                x = z->left;
                swap(z,z->left);
            }
            else{   // z has both children
                y = successor(z->right);  // Find successor in right subtree
                originalColor = y->color;
                x = y->right;
                if(y->parent == z)
                    x->parent = y;
                else{
                    swap(y,y->right);
                    y->right = z->right;
                    y->right->parent = y;
                }
                swap(z,y);    // Replace z with y
                y->left = z->left;
                y->left->parent = y;
                y->color = z->color;
            }
            updateSize(x->parent);  // Update size after deletion
            delete z;
            if(originalColor == 1)  // Fix red black tree properties if needed
                fixDelete(x);   
        }

        // Function to fix Red-Black Tree properties after deletion
        void fixDelete(Node* x) {
            while(x != root && x->color == 1) {
                if(x == x->parent->left) {  // x is a left child
                    Node* w = x->parent->right;
                    if(w->color == 0) { // w is red
                        w->color = 1;
                        x->parent->color = 0;
                        leftRotate(x->parent);
                        w = x->parent->right;
                    }
                    if(w->left->color == 1 && w->right->color == 1) {   // Both w's children are black
                        w->color = 0;
                        x = x->parent;
                    }
                    else{
                        if(w->right->color == 1) {  // w's right child is black
                            w->left->color = 1;
                            w->color = 0;
                            rightRotate(w);
                            w = x->parent->right;
                        }
                        w->color = x->parent->color;    // w's right child is red
                        x->parent->color = 1;
                        w->right->color = 1;
                        leftRotate(x->parent);
                        x = root;
                    }
                }
                else{   // Symmetric case
                    Node* w = x->parent->left;
                    if(w->color == 0) { // Check for each of the four possible cases
                        w->color = 1;
                        x->parent->color = 0;
                        rightRotate(x->parent);
                        w = x->parent->left;
                    }
                    if(w->right->color == 1 && w->left->color == 1) {
                        w->color = 0;
                        x = x->parent;
                    }
                    else{
                        if(w->left->color == 1) {
                            w->right->color = 1;
                            w->color = 0;
                            leftRotate(w);
                            w = x->parent->left;
                        }
                        w->color = x->parent->color;
                        x->parent->color = 1;
                        w->left->color = 1;
                        rightRotate(x->parent);
                        x = root;
                    }
                }
            }
            x->color = 1;   // Ensure x is black after fixing
        }

        // Function to find the k-th smallest element in the Red-Black Tree
        int findKthSmallest(int k) {
            Node* node = root;
            while(node != nil) {
                int leftSize = node->left->size;    // Get size of left subtree
                if(k == leftSize + 1)
                    return node->data;
                else if(k <= leftSize)  // If k is smaller, go to left subtree
                    node = node->left;
                else{   // If k is greater, go to right and adjust k
                    k -= (leftSize + 1);
                    node = node->right;
                }
            }
            throw runtime_error(" is out of bounds");   // k exceeds total number of nodes in tree, or is 0 or negative
        }

        // Function to find the rank of a node with a given key
        int findRank(int key) {
            Node* node = search(root,key);  // Find the node with the given key
            int rank = node->left->size + 1;
            while(node != root) {   // Traverse up to root, adjusting rank based on ancestor relationships
                if(node == node->parent->right)
                    rank += node->parent->left->size + 1;
                node = node->parent;
            }
            return rank-1;  // Return adjusted rank
        }

        // Helper functino to insert a node, since root is private member of the class
        void insert(int key) {
            Node* z = new Node(key);
            insert(z);
        }

        // Helper functino to delete a node, since root is private member of the class 
        void deleteKey(int key) {
            deleteNode(key);
        }

        // Helper function that returns the root of the tree
        Node* getRoot() {
            return root;
        }

        // Function for pre order traversal of the tree
        void preOrder(Node* node) {
            if(node == nil) return;
            cout << node->data << " ";
            preOrder(node->left);
            preOrder(node->right);
        }

    private:
        Node* root;
        Node* nil;

        // Helper function to iteratively update the size of nodes
        void updateSize(Node* node) {
            while(node != nil) {
                node->size = node->left->size + node->right->size + 1;
                node = node->parent;
            }
        }

        // Function to replace one subtree with another
        void swap(Node* u, Node* v) {
            if(u->parent == nil)    // If u is root, set v as root
                root = v;
            else if(u == u->parent->left)   // If u is a left child, update left pointer
                u->parent->left = v;
            else    // Update right pointer
                u->parent->right = v;
            v->parent = u->parent;  // Set v's parent to u's parent
        }

        // Helper function that returns the minimum element in right subtree (successor) of a node
        Node* successor(Node* node) {
            while(node->left != nil)
                node = node->left;
            return node;
        }
};

int main() {
    RBTree T;   // Create a default red black tree
    int n;
    cin>>n; // Insert n values into the tree
    for(int i = 0;i<n;i++) {
        int value;
        cin>>value;
        T.insert(value);
    }
    int k;  // Number of queries
    cin>>k;
    for(int i = 0;i<k;i++) {
        cout<<endl;
        int query,num;  // Queries to be handled
        cin>>query>>num;
        switch(query) {
            case 1: // Insert
                try{
                    T.search(T.getRoot(),num);  // Appropriate error handling for insert, delete, rank and out of bounds cases
                    cout<<num<<" is already present. So no need to insert"<<endl;
                }
                catch(runtime_error &e) {
                    T.insert(num);
                    cout<<num<<" is inserted"<<endl;
                }
                break;
            case 2: // Delete
                try{
                    T.deleteKey(num);
                    cout<<num<<" is deleted"<<endl;
                }
                catch(runtime_error &e) {
                    cout<<num<<" is not present. So it can not be deleted"<<endl;
                }
                break;
            case 3: // Find k-th smallest element
                try{
                    cout<<T.findKthSmallest(num)<<endl;
                }
                catch(runtime_error &e) {
                    cerr<<num<<e.what()<<endl;
                }
                break;
            case 4: // Find rank
                try{
                    cout<<T.findRank(num)<<endl;
                }
                catch(runtime_error &e) {
                    cout<<num<<" is not present in tree"<<endl;
                }
                break;
            default:
                cout<<"Invalid query"<<endl;
            }
        }
    cout<<endl;
    return 0;
}