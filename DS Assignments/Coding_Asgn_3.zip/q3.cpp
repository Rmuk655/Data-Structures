#include <iostream>
#include <vector>
using namespace std;

class RBTree {
    public:
        struct Node {
            int data;
            Node* left;
            Node* right;
            Node* parent;
            bool colour; // 0 for red, 1 for black

            Node(int x) : data(x), left(nullptr), right(nullptr), parent(nullptr), colour(0) {} // New nodes are red by default
        };

        RBTree() {  // Constructor to initialize the Red-Black Tree with a sentinel node
            nil = new Node(0);
            nil->colour = 1; // Sentinel node is always black
            root = nil;
        }

        ~RBTree() { // Simple destructor
            clear(root);
            delete nil;
        }

        void clear(Node* node) {    // Recursive function to delete all nodes in the tree
            if(node != nil) {
                clear(node->left);
                clear(node->right);
                delete node;
            }
        }

        // Helper functino to insert a node, since root is private member of the class
        void insert(int key) {
            Node* z = new Node(key);
            insert(z);
        }

        // Function to enumerate nodes within a given range [a, b]
        void RB_ENUMERATE(Node* node, int a, int b) {
            if (node == nil)    // Error handling, if node is nil, return
                return; 
            if(node->data >= a && node->left != nil)    // Recursively search in left subtree
                RB_ENUMERATE(node->left,a,b);
            if(node->data >= a && node->data <= b)
                cout<<node->data<<" ";  // Output the node if it's within range
            if(node->data <= b && node->right != nil)
                RB_ENUMERATE(node->right,a,b);  // Recursively search in right subtree
            return;
        }

        // Helper function that returns the root of the tree
        Node* getRoot() {
            return root;
        }

    private:
        Node* root;
        Node* nil;  // Sentinel node

        void leftRotate(Node* x) {  // Function to perform a left rotation on a node
            Node* y = x->right;
            x->right = y->left; // Turn y's left subtree into x's right subtree
            if(y->left != nil)
                y->left->parent = x;
            y->parent = x->parent;  // Link x's parent to y
            if(x->parent == nil)
                root = y;
            else if(x == x->parent->left)
                x->parent->left = y;
            else
                x->parent->right = y;
            y->left = x;    // Place x on y's left
            x->parent = y;
        }

        void rightRotate(Node* y) { // Function to perform a right rotation on a node
            Node* x = y->left;
            y->left = x->right; // Turn x's right subtree into y's left subtree
            if(x->right != nil)
                x->right->parent = y;
            x->parent = y->parent;  // Link y's parent to x
            if(y->parent == nil)
                root = x;
            else if(y == y->parent->right)
                y->parent->right = x;
            else
                y->parent->left = x;
            x->right = y;   // Place y on x's right
            y->parent = x;
        }

        Node* insert(Node* z) { // Insert function to add a node to the Red-Black Tree
            Node* y = nil;  // Parent of the node to be inserted
            Node* x = root;
            while(x != nil) {   // Simple BST insertion
                y = x;
                if(z->data < x->data)
                    x = x->left;
                else
                    x = x->right;
            }
            z->parent = y;
            if(y == nil)
                root = z;
            else if(z->data < y->data)
                y->left = z;
            else
                y->right = z;
            z->left = nil;
            z->right = nil;
            z->colour = 0; // New nodes are red
            return fixInsert(z);   // Correcting the properties of red black tree
        }

        Node* fixInsert(Node* z) { // Fixes Red-Black Tree properties after insertion
            while(z->parent->colour == 0) { // Loop until parent is black
                if(z->parent == z->parent->parent->left) {
                    Node* y = z->parent->parent->right;
                    if(y->colour == 0) {
                        z->parent->colour = 1;  // In case y is red
                        y->colour = 1;
                        z->parent->parent->colour = 0;
                        z = z->parent->parent;
                    }
                    else{   // Case where y is black
                        if(z == z->parent->right) {
                            z = z->parent;
                            leftRotate(z);
                        }
                        z->parent->colour = 1;
                        z->parent->parent->colour = 0;
                        rightRotate(z->parent->parent);
                    }
                }
                else{   // Symmetric cases for right child
                    Node* y = z->parent->parent->left;
                    if(y->colour == 0) {
                        z->parent->colour = 1;
                        y->colour = 1;
                        z->parent->parent->colour = 0;
                        z = z->parent->parent;
                    }
                    else{
                        if(z == z->parent->left) {
                            z = z->parent;
                            rightRotate(z);
                        }
                        z->parent->colour = 1;
                        z->parent->parent->colour = 0;
                        leftRotate(z->parent->parent);
                    }
                }
            }
            root->colour = 1; // Root must always be black
            return z;
        }
};

int main() {
    RBTree T;   // Create a default red black tree
    int n;  
    cin>>n;
    for(int i = 0;i<n;i++) {    // Insert n values into the tree
        int value;
        cin>>value;
        T.insert(value);
    }
    int k;  // Number of queries
    cin>>k;
    for(int i = 0;i<k;i++) {
        int a,b;
        cin>>a>>b;  // Queries to be handled
        if(a<=b)
            T.RB_ENUMERATE(T.getRoot(),a,b);
        else
            cout<<"The second value in range must be greater than or equal to the first";   // Appropriate error handling
        cout<<endl;
    }
    return 0;
}