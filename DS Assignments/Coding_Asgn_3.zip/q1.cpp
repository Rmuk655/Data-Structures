#include <iostream>
#include <queue>
using namespace std;

// Struct definition of a B-tree node
struct BTreeNode {
    int* key;         // Array of keys
    int count;                // Number of keys in the node
    BTreeNode **children; // Array of child pointers

    BTreeNode(int MAX) : count(0) {
        key = new int[MAX + 1];
        children = new BTreeNode*[MAX + 1];
        for(int i = 0;i<=MAX;i++)
            children[i] = nullptr;
    }
};

// B-tree class definition
class BTree {
    BTreeNode *root;  // Pointer to root node
    int t;            // Degree of the tree
    int MAX;          // Maximum keys a node can hold

    public:
        BTree(int deg) : root(nullptr), t(deg), MAX(2*deg-1) {} // Parameterized Constructor
        void levelOrder();  // Public functions for traversal, search, insertion, and deletion
        BTreeNode* search(int k);
        void insert(int k);
        void remove(int k);

    private:     // Helper functions for internal operations
        void levelOrder(BTreeNode* node);
        BTreeNode* search(BTreeNode* node, int k);
        void insertNonFull(BTreeNode* node, int k);
        void split(BTreeNode* parent, int i, BTreeNode* child);
        int findKey(BTreeNode* node, int k);
        void deleteNode(BTreeNode* node, int k);
        void deleteFromLeaf(BTreeNode* node, int idx);
        void deleteFromNonLeaf(BTreeNode* node, int idx);
        int Pred(BTreeNode* node, int idx);
        int Suc(BTreeNode* node, int idx);
        void fill(BTreeNode* node, int idx);
        void Prev(BTreeNode* node, int idx);
        void Next(BTreeNode* node, int idx);
        void merge(BTreeNode* node, int idx);
};

// Function to search a key in this tree
BTreeNode* BTree::search(int k) {
    return search(root,k);
}

// Recursive search function
BTreeNode* BTree::search(BTreeNode* node, int k) {
    if(!node)
    return nullptr;
    int i = 0;
    while(i < node->count && k > node->key[i])
        i++;
    if(i < node->count && node->key[i] == k)
        return node;
    return search(node->children[i],k);
}

// Level-order traversal wrapper
void BTree::levelOrder() {
    if(root)
        levelOrder(root);
}

// Level-order traversal of the B-tree nodes with specified formatting
void BTree::levelOrder(BTreeNode* node) {
    if(!node)
        return;
    queue<BTreeNode*> q;
    q.push(node);
    while(!q.empty()) {
        int size = q.size();
        bool first = true; // To manage comma formatting for the first element in the node
        for(int i = 0;i<size;i++) {
            BTreeNode* curr = q.front();
            q.pop();
            if(!first)
                cout << " "; // Add space before subsequent nodes in the same level
            first = false;
            for(int j = 0;j < curr->count;j++) { // Print keys in the current node
                cout<<curr->key[j];
                if(j < curr->count - 1)
                    cout<<","; // Comma after keys within the same node
            }
            for(int j = 0;j <= curr->count;j++)  // Add children to the queue
                if(curr->children[j])
                    q.push(curr->children[j]);
        }
        cout<<endl; // New line after each level
    }
}

// Insert function
void BTree::insert(int k) {
    if(!root) {
        root = new BTreeNode(MAX);
        root->key[0] = k;
        root->count = 1;
    }
    else{
        if(root->count == MAX) {    // If root is full, split it
            BTreeNode* s = new BTreeNode(MAX);
            s->children[0] = root;
            split(s,0,root);
            int i = 0;
            if(s->key[0] < k)
                i++;
            insertNonFull(s->children[i],k);
            root = s;
        }
        else
            insertNonFull(root,k);
    }
}

// Function to insert key into a non-full node
void BTree::insertNonFull(BTreeNode* node, int k) {
    int i = node->count - 1;
    if(!node->children[0]) {    // If node is a leaf
        while(i >= 0 && node->key[i] > k) {
            node->key[i+1] = node->key[i];
            i--;
        }
        node->key[i + 1] = k;
        node->count++;
    }
    else{   // Node is not a leaf
        while(i>=0 && node->key[i] > k)
            i--;
        if(node->children[i+1]->count == MAX) {
            split(node,i+1,node->children[i+1]);
            if(node->key[i + 1] < k)
                i++;
        }
        insertNonFull(node->children[i+1],k);
    }
}

// Split the child of a node
void BTree::split(BTreeNode* parent, int i, BTreeNode* child) {
    BTreeNode* newNode = new BTreeNode(MAX);
    newNode->count = t-1;
    for(int j = 0;j<t-1;j++)    // Copy the upper half of keys from the full child to the new node
        newNode->key[j] = child->key[j+t];

    if(child->children[0]) {    // If the full child has children, split and copy them as well
        for(int j = 0;j<t;j++)
            newNode->children[j] = child->children[j+t];
    }
    child->count = t-1;
    for(int j = parent->count;j >= i+1;j--)     // Insert the new node as a child of the parent and shift other children if necessary
        parent->children[j+1] = parent->children[j];
    parent->children[i+1] = newNode;
    for(int j = parent->count - 1;j>=i;j--)     // Move the median key from the full child to the parent
        parent->key[j+1] = parent->key[j];
    parent->key[i] = child->key[t-1];
    parent->count++;
}

// Find the index of the first key greater than or equal to k
int BTree::findKey(BTreeNode* node, int k) {
    int idx = 0;
    while (idx < node->count && node->key[idx] < k)
        idx++;
    return idx;
}

// Remove a key from the B-tree
void BTree::remove(int k) {
    if(!root)
        return;
    deleteNode(root,k);
    if(root->count == 0) {
        BTreeNode* tmp = root;
        root = (root->children[0]) ? root->children[0] : nullptr;
        delete tmp;
    }
}

// Helper function to delete a key from a node
void BTree::deleteNode(BTreeNode* node, int k) {
    int idx = findKey(node,k);
    if(idx < node->count && node->key[idx] == k) {
        if(!node->children[0])      // Key is in a leaf node, simply remove it
            deleteFromLeaf(node,idx);
        else
            deleteFromNonLeaf(node,idx);    // Key is in a non-leaf node, use in-order predecessor or successor.
    }
    else{
        if(!node->children[0]) {    // If key is not in the node and it is a leaf, key does not exist
            cout<<"The key "<<k<<" does not exist in the tree"<<endl;
            return;
        }
        bool flag = (idx == node->count);   // Check for underflow
        if(node->children[idx]->count < t)
            fill(node,idx);
        if(flag && idx > node->count)       // Recursive delete and checking if merge may have shifted child index
            deleteNode(node->children[idx-1],k);
        else
            deleteNode(node->children[idx],k);
    }
}

// delete from leaf
void BTree::deleteFromLeaf(BTreeNode* node, int idx) {
    for(int i = idx+1;i < node->count;i++)
        node->key[i-1] = node->key[i];
    node->count--;
}

// delete from non-leaf
void BTree::deleteFromNonLeaf(BTreeNode* node, int idx) {
    int k = node->key[idx];
    if(node->children[idx]->count >= t) {   // The left child has enough keys to replace the deleted key
        int pred = Pred(node,idx);
        node->key[idx] = pred;
        deleteNode(node->children[idx],pred);
    }
    else if(node->children[idx+1]->count >= t) {    // The right child has enough keys to replace the deleted key
        int succ = Suc(node,idx);
        node->key[idx] = succ;
        deleteNode(node->children[idx+1],succ);
    }
    else{   // Both children have minimum keys, so merge them
        merge(node,idx);
        deleteNode(node->children[idx],k);
    }
}

// Get predecessor
int BTree::Pred(BTreeNode* node, int idx) {
    BTreeNode* cur = node->children[idx];
    while(cur->children[0]) // Only navigate through non-leaf nodes
        cur = cur->children[cur->count];
    return cur->key[cur->count - 1];
}

// Get successor
int BTree::Suc(BTreeNode* node, int idx) {
    BTreeNode* cur = node->children[idx+1];
    while(cur->children[0]) // Only navigate through non-leaf nodes
        cur = cur->children[0];
    return cur->key[0];
}

// Fill a node if it has fewer than t keys
void BTree::fill(BTreeNode* node, int idx) {
    if(idx != 0 && node->children[idx-1]->count >= t)
        Prev(node,idx);
    else if(idx != node->count && node->children[idx+1]->count >= t)
        Next(node,idx);
    else{
        if(idx != node->count)
            merge(node,idx);
        else
            merge(node,idx-1);
    }
}

// Borrow from previous sibling
void BTree::Prev(BTreeNode* node, int idx) {
    BTreeNode* child = node->children[idx];
    BTreeNode* next = node->children[idx-1];
    for(int i = child->count - 1;i>=0;i--)  // Shift all keys in child to the right to make space for the borrowed key
        child->key[i+1] = child->key[i];
    if(child->children[0]) {
        for(int i = child->count;i>=0;i--)
            child->children[i+1] = child->children[i];
    }
    child->key[0] = node->key[idx-1];   // Borrow the key from the parent and move the sibling's last key to the parent
    if(child->children[0])
        child->children[0] = next->children[next->count];
    node->key[idx-1] = next->key[next->count - 1];
    child->count++;     // Update key counts in both nodes
    next->count--;
}

// Borrow from next sibling
void BTree::Next(BTreeNode* node, int idx) {
    BTreeNode* child = node->children[idx];
    BTreeNode* next = node->children[idx + 1];
    child->key[child->count] = node->key[idx];  // Move the borrowed key from the parent to the current child
    if(child->children[0])
        child->children[child->count + 1] = next->children[0];
    node->key[idx] = next->key[0];
    for(int i = 1;i < next->count;i++)  // Shift all keys in the sibling to the left
        next->key[i-1] = next->key[i];
    if(next->children[0]) {
        for(int i = 1;i <= next->count;i++)
            next->children[i-1] = next->children[i];
    }
    child->count++;     // Update key counts in both nodes
    next->count--;
}

// Merge two nodes
void BTree::merge(BTreeNode* node, int idx) {
    BTreeNode* child = node->children[idx];
    BTreeNode* next = node->children[idx+1];
    child->key[t-1] = node->key[idx];   // Move the key from the parent down into the merged node
    for(int i = 0;i < next->count;i++)  // Move all keys and child pointers from the sibling to the merged node
        child->key[i+t] = next->key[i];
    if(child->children[0]) {
        for(int i = 0;i <= next->count;i++)
            child->children[i+t] = next->children[i];
    }
    for(int i = idx+1;i < node->count;i++)     // Shift keys and children of the parent to fill the gap
        node->key[i-1] = node->key[i];
    for(int i = idx+2;i <= node->count;i++)
        node->children[i-1] = node->children[i];
    child->count += next->count + 1;
    node->count--;
    delete next;    // Delete next node as it is repeated
}

int main() {
    int n,max,min;
    cin>>n>>max>>min;
    if(max != 2*min+1 || min<=0) {
        cout<<"Incorrect values for min and max"<<endl;
        return 0;
    }
    BTree T(min+1);  // Create a B-tree with minimum degree as needed
    int ele;
    for(int i=0;i<n;i++) {
        cin>>ele;
        T.insert(ele);
    }
    int num;    // Number of queries
    cin>>num;
    while(num--) {
        int op,ele;
        cin>>op;    // Queries to be handled
        switch(op) {
            case 1:
                cin>>ele;
                if(T.search(ele) != nullptr)
                    cout<<ele<<" is present"<<endl;
                else
                    cout<<ele<<" is not present"<<endl;
                break;
            
            case 2:
                cin>>ele;
                if(T.search(ele) != nullptr)    // Handling the appropriate errors in insertions and deletion
                    cout<<ele<<" is already present. So no need to insert"<<endl;
                else{
                    T.insert(ele);
                    cout<<ele<<" is inserted"<<endl;
                }
                break;

            case 3:
                cin>>ele;
                if(T.search(ele) == nullptr)
                    cout<<ele<<" is not present. So it can not be deleted"<<endl;
                else{
                    T.remove(ele);
                    cout<<ele<<" is deleted"<<endl;
                }
                break;
            
            case 4:
                cout<<endl;
                T.levelOrder();
                cout<<endl;
                break;
            
            default:
                cout<<"Incorrect query number"<<endl;
        }
    }
    return 0;
}