#include<iostream>
#include<vector>
#include<unordered_map>

using namespace std;

class Graph {

    private:
    
        unordered_map<int,vector<int>> adj; // Adjacency list for storing graph edges
        int n,m;    // Number of vertices is 2n (1,-1,2,-2...n,-n) and edges is m

    public:

        Graph(int x, int y) {   // Constructor to initialize the graph with 2n vertices and m edges
            n=x;
            m=y;
        }

        ~Graph() {} // Default destructor

        void insert(int x, int y) { // Function to insert an edge from -x to y and -y to x
            adj[-x].push_back(y);
            adj[-y].push_back(x);
            return;
        }

        void dfs(int vertex, unordered_map<int,int>& colour){    // Depth-first search function to traverse the graph
            colour[vertex] = 1;     // Mark vertex as visiting or grey
            for(int i=0;i<adj[vertex].size();i++){
                int ans = adj[vertex][i];
                if(!colour[ans])    // If ans is unvisited (white)
                    dfs(ans,colour);
            }
            colour[vertex] = 2; // Mark vertex as visited (black)
            return;
        }

        bool path(int start, int end){   // Function to check if there is a path between start and end vertices
            unordered_map<int,int> colours;  // Colour map to track visited status of vertices
            for(int i=1;i<n+1;i++)
                colours[i] = 0;     // Initialize all vertices as unvisited
            dfs(start,colours);     // Perform DFS
            if(colours[end]==2) 
                return true;
            return false;
        }

        int check() {   // Function to check if the graph is satisfiable
            for(int i=1;i<n+1;i++){
                if(path(i,-i) && path(-i,i)){   // Check if there is a path from i to -i and from -i to i
                    cout<<"Unsatifiable"<<endl;
                    return -1;
                }
            }
            return 0;
        }

        void solutions() {  // Function to print solutions if the graph is satisfiable
            vector<int> num(n+1,-1);    // Array to store boolean values of each variable (initialized to -1)
            for(int i=1;i<n+1;i++){
                if(num[i] == -1) {      // If variable i is not yet assigned
                    unordered_map <int,int> colours;
                    dfs(i,colours);     // Perform DFS from i to mark reachable nodes
                    if(!colours[-i]) {
                        num[i] = 1;     // If -i is not reachable from i, assign true (1) to variable i
                        for(int j=1;j<n+1;j++){
                            if(colours[j] == 2)
                                num[j] = 1;     // If j is reachable, assign true
                            else if(colours[-j] == 2) 
                                num[j] = 0;     // If -j is reachable, assign false
                        }
                    }
                }
            }
            for(int i=1;i<n+1;i++) 
                cout<<num[i]<<" ";      // Print the value of each variable
            cout<<endl;
        }
};

int main(){
    int t;
    cin>>t;
    while(t--){
        int n,m;    // Number of variables (n) and clauses (m) for each test case
        cin>>n>>m;  
        Graph G(n,m);
        for(int i=0;i<m;i++){
            int a,b;
            cin>>a>>b;
            G.insert(a,b);      // If a + b is present, it is equivalent to a->b as well as b->a
        }
        int count = G.check();  // Check if the graph is satisfiable, and if so, print solutions
        if(count==0)
            G.solutions();
    }
    return 0;
}