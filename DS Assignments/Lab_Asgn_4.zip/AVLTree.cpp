#include <iostream>
using namespace std;

class AVL {
    public:
        struct Node {
            int data;
            int height;
            Node* left;
            Node* right;

            Node(int x) {       // Default constructor for the Node structure
                data = x;
                left = nullptr;
                right = nullptr;
                height = 1;  // New node is initially added at leaf
            }
        };

        AVL() {  // Default constructor
            root = nullptr;
        }

        ~AVL() {};  //Default destructor

        int height(Node* N) {
            if(N == nullptr)
                return 0;
            return N->height;
        }

        int heightDiff(Node* N) {       // Function to find the balance of the tree
            if(N == nullptr)
                return 0;
            return height(N->left)-height(N->right);
        }

        Node* leftRotate(Node* x) {  // Function to perform left rotation
            Node* y = x->right;
            Node* T2 = y->left;
            y->left = x;        // Performing rotations
            x->right = T2;
            x->height = (height(x->left) > height(x->right)) ? height(x->left): height(x->right);  // Updating height of respective nodes
            x->height++;
            y->height = (height(y->left) > height(y->right)) ? height(y->left) : height(y->right);
            y->height++;
            return y;
        }

        Node* rightRotate(Node* y) {  // Perform right rotation
            Node* x = y->left;
            Node* T2 = x->right;
            x->right = y;   // Performing the rotations
            y->left = T2;
            y->height = (height(y->left) > height(y->right)) ? height(y->left) : height(y->right);     // Updating height of respective nodes
            y->height++;
            x->height = (height(x->left) > height(x->right)) ? height(x->left) : height(x->right);
            x->height++;
            return x;
        }

        Node* search(Node* node,int key) {     // Function to search for a value in a tree, and throw an error if the key is not found
            if(node == nullptr)
                throw runtime_error(" key is not present in the tree");
            if(key == node->data)
                return node;
            else if(key > node->data) 
                return search(node->right,key);
            else
                return search(node->left,key);
        }

        /**
         * Firstly, we insert a node normally as we do for a binary search tree
         * Then, we check if the AVL tree is balanced by finding the height difference
         * If the node becomes unbalanced, there are 4 cases, each of which we check and balance the tree again
         */

        Node* insert(Node* node,int key) {
            if(node == nullptr)
                return new Node(key);
            if(key < node->data)
                node->left = insert(node->left,key);
            else if(key > node->data)
                node->right = insert(node->right,key);
            else
                throw runtime_error("Node with this key value already exists");  // Duplicate keys are not allowed in AVL tree  
            node->height = (height(node->left) > height(node->right)) ? height(node->left) : height(node->right);
            node->height++;
            int diff = heightDiff(node); // Height difference to check the balanced condition
            if(diff>1 && key < node->left->data) // Begin checking each of the four cases: left-left, left-right, right-left and right-right; and balance the tree
                return rightRotate(node);
            if(diff<-1 && key > node->right->data)
                return leftRotate(node);
            if(diff>1 && key > node->left->data) {
                node->left = leftRotate(node->left);
                return rightRotate(node);
            }
            if(diff<-1 && key < node->right->data) {
                node->right = rightRotate(node->right);
                return leftRotate(node);
            }
            return node;
        }

        void preOrder(Node* root) {     // Function to print the pre order traversal of the tree
            if(root != nullptr) {
                cout<<root->data<<" ";
                preOrder(root->left);
                preOrder(root->right);
            }
        }

        void inOrder(Node* root) {      // Function to print the in order traversal of the tree
            if(root != nullptr) {
                inOrder(root->left);
                cout<<root->data<<" ";
                inOrder(root->right);
            }
        }

        void postOrder(Node* root) {        // Function to print the post order traversal of the tree
            if(root != nullptr) {
                postOrder(root->left);
                postOrder(root->right);
                cout<<root->data<<" ";
            }
        }

        Node* getRoot() {       // Utility function that outputs the root node of the tree
            return root;
        }

        // Designing a utility insert function that uses the actual insert(root,key) function
        void insert(int key) {          // Simple insert function that only takes the key, as the root is present as a member of the class
            try{
                root = insert(root,key);
                cout<<"Key "<<key<<" has been inserted succesfully."<<endl;
                cout<<"Pre Order traversal of the tree after inserting key "<<key<<" is: "<<endl;
                preOrder(getRoot());
                cout<<endl;
                cout<<"In Order traversal of the tree after inserting key "<<key<<" is: "<<endl;
                inOrder(getRoot());
            }
            catch(runtime_error &e) {
                cerr<<"Error: "<<key<<" is already present. "<<e.what()<<endl;
            }
            cout<<endl;
        }

    private:
        Node* root;
};

int main() {
    AVL T;
    int construct[] = {9, 8, 5, 4, 99, 78, 31, 34, 89, 90, 21, 23, 45, 77, 88, 112, 32};   // Construction array given in problem statement
    for(int i : construct) {
        T.insert(i);
        cout<<endl;
    }
    int searching[] = {32, 56, 90};     // Searching elements given in the problem statement
    for(int i : searching) {
        try{
            T.search(T.getRoot(),i);
            cout<<"Key "<<i<<" is present in the tree."<<endl;
        }
        catch(runtime_error& e) {
            cerr<<"Error: "<<i<<e.what()<<endl;
        }
        cout<<endl;
    }
    int inserting[] = {132, 156, 11, 7};     // Elements to insert given in the problem statement
    for(int i : inserting) {
        T.insert(i);
        cout<<endl;
    }
    return 0;
}
