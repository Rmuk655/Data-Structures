#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
using namespace std;

class Tree {
    public:
        struct Node {        // A node structure with pointers to left and right children. This is the basic unit of the Tree
            string data;
            Node* left;
            Node* right;
            Node() {
                data = "";
                left = nullptr;
                right = nullptr;
            }
            Node(string str) {
                data = str;
                left = nullptr;
                right = nullptr;
            }
        };

        Tree() {            // A simple default constructor for the tree
            root = nullptr;
        }

        Tree(string key) {     // A parameterized constructor using the createNode functions
            root = createNode(key);
        }

        ~Tree() {}  // A simple destructor to clean-up memory of the Tree object

        Node* createNode(string key) {   // Creates a new node with the given key value to be inserted into the tree
            return new Node(key);
        }

        void insertLeft(Node* root, string key) {  // Creates a new node with the given value and inserts it as the left child of a given node
            root->left = createNode(key);
        }

        void insertRight(Node* root, string key) {  // Creates a new node with the given value and inserts it as the right child of a given node
            root->right = createNode(key);
        }

        int getHeight(Node* node) {    // Helper function to calculate the height of the tree
            if(node == nullptr)
                return 0;
            int leftHeight = getHeight(node->left);
            int rightHeight = getHeight(node->right);
            return 1 + ((leftHeight > rightHeight) ? leftHeight : rightHeight);
        }

        void preOrder(Node* root) {   // A function to print the tree recursively using pre-order traversal
            if(root == nullptr) 
                return;
            cout<<root->data<<" ";
            preOrder(root->left);
            preOrder(root->right);
        }

        void inOrder(Node* root) {   // A function to print the tree recursively using in-order traversal
            if(root == nullptr) 
                return;
            inOrder(root->left);
            cout<<root->data<<" ";
            inOrder(root->right);
        }

        void postOrder(Node* root) {  // A function to print the tree recursively using post-order traversal
            if(root == nullptr) 
                return;
            postOrder(root->left);
            postOrder(root->right);
            cout<<root->data<<" ";
        }

        int findIndex(const vector<string>& postorder,int beg,int end,string val) {   // Function to find the index of the root in the inorder array
            for(int i=beg;i<=end;i++) {
                if(postorder[i] == val)
                    return i;
            }
            throw runtime_error("ERROR");
        }

        Node* getTree(const vector<string>& preorder,const vector<string>& postorder,int beg,int end,int& index) {  // Function to build tree from postorder and preorder traversals
            if(beg > end || index >= postorder.size()) 
                return nullptr;
            string num = preorder[index++];  // Get root value from postorder and store it in num
            Node* root = createNode(num);
            if(beg == end)
                return root;
            string child = preorder[index]; 
            int postIndex = findIndex(postorder,beg,end,child); // Find the index of root in inorder traversal
            root->left = getTree(preorder,postorder,beg,postIndex,index);
            root->right = getTree(preorder,postorder,postIndex+1,end-1,index);
            return root;
        }

        Node* buildTree(const vector<string>& preorder, const vector<string>& postorder) { // Reconstruct tree from inorder and preorder arrays
            int preIndex = 0;
            return getTree(preorder,postorder,0,postorder.size()-1,preIndex);
        }

        void levelOrder(Node* root) {   // A function to get the array representation of a tree from the tree's structure
            if(root == nullptr)
                return;
            queue<Node*> nodes;      // Using an inbuilt queue to maintain and parse nodes
            vector<string> result;
            long long total = pow(2,getHeight(root)) - 1;
            nodes.push(root);
            while(!nodes.empty()) {
                Node* temp = nodes.front();
                nodes.pop();
                if(temp != nullptr) {
                    result.push_back(temp->data);
                    nodes.push(temp->left);
                    nodes.push(temp->right);
                }
                else{
                    result.push_back("NULL");
                    nodes.push(nullptr);  // To maintain the structure of the complete tree
                    nodes.push(nullptr);
                }
                if(result.size() >= total)
                break;
            }
            for(string &val : result)    // Print the array representation
                cout<<val<<" ";
        }
    
    private:
        Node* root;

};

int main() {
    int k;  // Number of test cases
    cin>>k;
    cin.ignore();
    while(k--){
        vector<string> preorder,postorder;
        string input;
        getline(cin,input);
        for(int i=0;i<input.size();i++) {
            string key = "";
            while(input[i]!=' ' && i<input.size()) {
                key += input[i];
                i++;
            }
            preorder.push_back(key);
        }
        getline(cin,input);
        for(int i=0;i<input.size();i++) {
            string key = "";
            while(input[i]!=' ' && i<input.size()) {
                key += input[i];
                i++;
            }
            postorder.push_back(key);
        }
        if(preorder.size() != postorder.size()) {
            cerr<<"ERROR"<<endl;
            continue;
        }
        Tree T;
        try{
            Tree::Node* root = T.buildTree(preorder,postorder);  // Build the tree from the given traversal orders and 'root' is the pointer to the root node of this tree
            T.levelOrder(root);  // Print or output the tree structure
            cout<<endl;
        }
        catch(runtime_error &e) {
            cerr<<e.what()<<endl;
        }
    }
    return 0;
}