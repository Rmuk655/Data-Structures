#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

class Tree {
    public:
        struct Node {        // A node structure with pointers to left and right children. This is the basic unit of the Tree
            string val;
            Node* left;
            Node* right;
            Node() {
                val = "";
                left = nullptr;
                right = nullptr;
            }
            Node(string str) {
                val = str;
                left = nullptr;
                right = nullptr;
            }
        };

        Tree() {            // A simple default constructor for the tree
            root = nullptr;
        }

        ~Tree() {}  // A simple destructor to clean-up memory of the Tree object

        Node* getRoot() {
            return root;
        }

        Node* buildTree(Node* node, vector<string> &keys, int index) {      // Reconstruct tree from array representation
            if(index >= keys.size() || keys[index] == "NULL")
              return nullptr;
            node = new Node(keys[index]);
            if(2*index < keys.size())
                node->left = buildTree(node->left,keys,2*index);
            if(2*index+1 < keys.size())
                node->right = buildTree(node->right,keys,2*index+1);
            return node;
        }

        void evaluate(Node* node) {     // Function to evaluate the expression of two leaves, and store the result in their parent node, which was initially an operator
            if(node->left == nullptr || node->right==nullptr)   // Represents a number
                return;
            if(node->left->left != nullptr || node->right->right != nullptr) {  // This means we have not yet reached a number
                evaluate(node->right);
                evaluate(node->left);
            }
            if(node->val=="+")  // Handle basic operators +,-,*,/,^
                node->val = to_string(stoll(node->left->val) + stoll(node->right->val));
            else if(node->val=="-")
                node->val = to_string(stoll(node->left->val) - stoll(node->right->val));
            else if(node->val=="*")
                node->val = to_string(stoll(node->left->val) * stoll(node->right->val));
            else if(node->val=="/") {
                if(stoll(node->right->val) == 0)    // Handle division by zero 
                    throw runtime_error("Division by zero is not permitted!!");
                node->val = to_string(stoll(node->left->val) / stoll(node->right->val));
            }
            else
                node->val = to_string(pow(stoll(node->left->val),stoll(node->right->val)));
            node->left = nullptr;
            node->right = nullptr;
        }

    private:
        Node* root;

};

int main() {
    int k;
    cin>>k;
    cin.ignore();
    while(k--) {
        vector<string> keys;
        keys.push_back("");
        string input;
        getline(cin,input);
        for(int i=0;i<input.size();i++) {        // Parsing the input string into the array representation
            string key = "";
            while(input[i]!=' ' && i<input.size()) {
                key += input[i];
                i++;
            }
            keys.push_back(key);
        }
        Tree T;
        Tree::Node* root = T.buildTree(T.getRoot(),keys,1);     // Building the tree, then evaluating it and printing the final result
        try{
        T.evaluate(root);
        cout<<root->val<<endl;
        }
        catch(runtime_error &e) {
            cerr<<"ERROR: "<<e.what()<<endl;
        }
    }
}