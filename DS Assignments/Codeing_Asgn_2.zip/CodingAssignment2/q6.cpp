#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

class Tree {
    public:
        struct Node {        // A node structure with pointers to left and right children. This is the basic unit of the Tree
            string val;
            Node* left;
            Node* right;
            Node() {
                val = "";
                left = nullptr;
                right = nullptr;
            }
            Node(string str) {
                val = str;
                left = nullptr;
                right = nullptr;
            }
        };

        Tree() {            // A simple default constructor for the tree
            root = nullptr;
        }

        ~Tree() {}  // A simple destructor to clean-up memory of the Tree object

        Node* getRoot() {
            return root;
        }

        Node* buildTree(Node* node, vector<string> &keys, int index, int dist) {    // Reconstruct tree from array representation
            if(index >= keys.size() || keys[index] == "NULL")
              return nullptr;
            node = new Node(keys[index]);
            vertical.push_back({dist,{index,node->val}});
            if(2*index < keys.size())
                node->left = buildTree(node->left,keys,2*index,dist-1);
            if(2*index+1 < keys.size())
                node->right = buildTree(node->right,keys,2*index+1,dist+1);
            return node;
        }

        void bubbleSort() {  // Implementing a simple bubble sort
            for(int i=0;i < vertical.size()-1;i++) {
                for(int j=0;j < vertical.size()-i-1;j++) {
                    if(vertical[j].first > vertical[j+1].first || (vertical[j].first == vertical[j+1].first && vertical[j].second.first > vertical[j+1].second.first)) {
                        auto temp = vertical[j];
                        vertical[j] = vertical[j+1];
                        vertical[j+1] = temp;
                    }
                }
            }
        }

        void verticalOrder() {      // Function to print the vertical order of the given tree
            bubbleSort();   // Sort so that the number coming first in the input array comes first in the output as well
            int min = vertical[0].first;    // Finding the maximum and minimum vertical distances from root
            int max = min;
            for(int i=1;i<vertical.size();i++) {
                if(vertical[i].first < min)
                    min = vertical[i].first;
                if(vertical[i].first > max)
                    max = vertical[i].first;
            }
            for(int i=min;i<=max;i++) {     // Printing all nodes with same depths, starting from the left-most going to the right
                for(int j=0;j<vertical.size();j++) {
                    if(vertical[j].first == i)
                        cout<<vertical[j].second.second<<" ";
                }
                cout<<endl;
            }
        }

    private:
        Node* root;
        vector<pair<int,pair<int,string>>> vertical;    // Behaves like a map, to store the data and its distance to left/right from the root

};

int main() {
    int k;
    cin>>k;
    int count = 1;
    cin.ignore();
    while(k--) {
        vector<string> keys;
        keys.push_back("");
        string input;
        getline(cin,input);
        for(int i=0;i<input.size();i++) {       // Parsing the input string into the array representation
            string key = "";
            while(input[i]!=' ' && i<input.size()) {
                key += input[i];
                i++;
            }
            keys.push_back(key);
        }
        Tree T;
        Tree::Node* root = T.buildTree(T.getRoot(),keys,1,0);   // Building the tree, then printing its vertical order traversal
        cout<<"Tree : "<<count<<endl;
        T.verticalOrder();
        count++;
    }
}