#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Tree {
    public:
        struct Node {       // A node structure with pointers to left and right children. This is the basic unit of the Tree
            string val;
            Node* left;
            Node* right;
            Node(string value) : val(value), left(nullptr), right(nullptr) {}   // Simple constructor for the node
        };

        Tree() {    // Default constructor for the tree
            root = nullptr;
        }

        ~Tree() {}  // Simple destructor

        Node* getRoot() {   // Utility function to get the root of the tree
            return root;
        }

        Node* buildTree(Node* node, vector<string> &keys, int index) {  // Reconstruct tree from array representation
            if(index >= keys.size() || keys[index] == "NULL")
              return nullptr;
            node = new Node(keys[index]);
            if(2*index < keys.size())
                node->left = buildTree(node->left,keys,2*index);
            if(2*index+1 < keys.size())
                node->right = buildTree(node->right,keys,2*index+1);
            return node;
        }

        /** Function to print the pre order traversal of the tree.
         * This uses a technique to rethread the nodes, and then combine them back during another traversal
         * Thus, the overall structure of the tree remains unchanged
         */
        void preOrder(Node* root) {     
            Node* curr = root;
            while(curr != nullptr) {
                if(curr->left == nullptr) {
                    cout<<curr->val<<" ";
                    curr = curr->right;
                } 
                else{
                    Node* prev = curr->left;
                    while(prev->right != nullptr && prev->right != curr)
                        prev = prev->right;
                    if(prev->right == nullptr) {
                        cout<<curr->val<<" "; 
                        prev->right = curr;
                        curr = curr->left;
                    }
                    else{
                        prev->right = nullptr;
                        curr = curr->right;
                    }
                }
            }
        }
        
         // Function to print the in order traversal of the tree using the vector of node pointers to behave as a stack, by popping and pushing only from one end
        void inOrder(Node* root) {     
            vector<Node*> stack;
            Node* curr = root;
            while(!stack.empty() || curr != nullptr) {
                while(curr != nullptr) {
                    stack.push_back(curr);
                    curr = curr->left;
                }
                curr = stack[stack.size()-1];
                stack.pop_back();
                cout<<curr->val<<" ";
                curr = curr->right;
            }
        }
        
        // Function to print the post order traversal of the tree, which again uses the vector of nodes as a stack
        void postOrder(Node* root) {       
            if(root == nullptr) 
                return;
            vector<Node*> stack;
            Node* prev = nullptr;
            Node* curr = root;
            while(!stack.empty() || curr != nullptr) {
                if(curr != nullptr) {
                    stack.push_back(curr);
                    curr = curr->left;
                }
                else{
                    Node* top = stack[stack.size()-1];
                    if(top->right != nullptr && prev != top->right)
                        curr = top->right;
                    else{
                        cout<<top->val<<" ";
                        prev = stack[stack.size()-1];
                        stack.pop_back();
                    }
                }
            }
        }

    private:
        Node* root;
};

int main() {
    int k;
    cin>>k;
    cin.ignore();
    while(k--) {
        vector<string> keys;
        keys.push_back("");
        string input;
        getline(cin,input);
        for(int i=0;i<input.size();i++) {   // Parsing the input string into the array representation
            string key = "";
            while(input[i]!=' ' && i<input.size()) {
                key += input[i];
                i++;
            }
            keys.push_back(key);
        }
        Tree T;
        Tree::Node* root = T.buildTree(T.getRoot(),keys,1); // Building the tree and printing the respective traversals
        T.inOrder(root);
        cout<<endl;
        T.preOrder(root);
        cout<<endl;
        T.postOrder(root);
        cout<<endl;
    }
    return 0;
}