#include <iostream>
#include <stdexcept>
using namespace std;

class RBTree {
    public:
        struct Node {
            int data;
            Node* left;
            Node* right;
            Node* parent;
            bool colour;  // 0 for red, 1 for black

            Node(int x) : data(x), left(nullptr), right(nullptr), parent(nullptr), colour(0) {}  // Default as red when inserted
        };

        RBTree() {      // Simple constructor for the class
            nil = new Node(0);  
            nil->colour = 1;    // Sentinel node is always black
            root = nil;
        }

        ~RBTree() {}    // Default destructor

        Node* leftRotate(Node* x) {     // Function to perform left rotation
            Node* y = x->right;
            x->right = y->left;
            if(y->left != nil)
                y->left->parent = x;
            y->parent = x->parent;
            if(x->parent == nil)
                root = y;
            else if(x == x->parent->left)
                x->parent->left = y;
            else
                x->parent->right = y;
            y->left = x;
            x->parent = y;
            return y;
        }

        Node* rightRotate(Node* y) {        // Function to perform right rotation
            Node* x = y->left;
            y->left = x->right;
            if(x->right != nil)
                x->right->parent = y;
            x->parent = y->parent;
            if(y->parent == nil)
                root = x;
            else if(y == y->parent->right)
                y->parent->right = x;
            else
                y->parent->left = x;
            x->right = y;
            y->parent = x;
            return x;
        }

        Node* search(Node* node, int key) {     // Function to search for a value in a tree, and throw an error if the key is not found
            if(node == nil)
                throw runtime_error(" key not found");
            if(key == node->data)
                return node;
            else if(key < node->data)
                return search(node->left,key);
            else
                return search(node->right,key);
        }

        /**
         * Inserts a new node with a given key into the Red-Black Tree.
         * 
         * Firstly, we insert a node normally as we do for a binary search tree. 
         * Then, we perform rebalancing if necessary. 
         * The rebalancing ensures that the Red-Black Tree properties are maintained
         * This fixes any colour violations that may occur.
         */
        Node* insert(Node* z) {
            Node* y = nil;
            Node* x = root;
            while (x != nil) {  // Find the position to insert
                y = x;
                if(z->data < x->data)
                    x = x->left;
                else
                    x = x->right;
            }
            z->parent = y;
            if(y == nil)     // If tree was empty
                root = z;
            else if(z->data < y->data)
                y->left = z;
            else
                y->right = z;
            z->left = nil;
            z->right = nil;
            z->colour = 0;  // New nodes are red
            return fix_insert(z);  // Fix any violations
        }

        /**
         * Fixes the Red-Black Tree after insertion to maintain balance.
         * 
         * After inserting a node, the tree may violate the Red-Black properties, such 
         * as having two consecutive red nodes. This function performs the necessary 
         * rebalancing by applying rotations and recolouring to restore the properties 
         * of the tree. The 3 main cases handled are:
         * 
         * - Case 1: Other child of parent's parent (otherwise called uncle) is red
         * - Case 2: 'Uncle' node is black, and the new node forms a triangle
         * - Case 3: 'Uncle' node is black, and the new node forms a straight line
         */
        Node* fix_insert(Node* z) {
            while(z->parent->colour == 0) {
                if(z->parent == z->parent->parent->left) {  // If z's parent is a left child
                    Node* y = z->parent->parent->right;
                    if(y->colour == 0) {  // Case 1 as described above
                        z->parent->colour = 1;
                        y->colour = 1;
                        z->parent->parent->colour = 0;
                        z = z->parent->parent;
                    }
                    else{
                        if(z == z->parent->right) {  // Case 2
                            z = z->parent;
                            leftRotate(z);
                        }
                        z->parent->colour = 1;  // Case 3
                        z->parent->parent->colour = 0;
                        rightRotate(z->parent->parent);
                    }
                }
                else{  // Symmetric case
                    Node* y = z->parent->parent->left;
                    if(y->colour == 0) {  // Case 1
                        z->parent->colour = 1;
                        y->colour = 1;
                        z->parent->parent->colour = 0;
                        z = z->parent->parent;
                    }
                    else{
                        if(z == z->parent->left) {  // Case 2
                            z = z->parent;
                            rightRotate(z);
                        }
                        z->parent->colour = 1;  // Case 3
                        z->parent->parent->colour = 0;
                        leftRotate(z->parent->parent);
                    }
                }
            }
            root->colour = 1;  // Root must always be black
            return z;
        }

        // Designing a utility insert function that uses the actual insert function
        void insert(int key) {      // Simple insert function that only takes the key, as the root is present as a member of the class
            try{
                Node* z = new Node(key);
                insert(z);
                cout<<"Key "<<key<<" has been inserted successfully."<<endl;
                cout<<"In Order traversal of the tree after inserting key "<<key<<" is: "<<endl;
                inOrder(getRoot());
                cout<<endl;
                cout<<"Pre Order traversal of the tree after inserting key "<<key<<" is: "<<endl;
                preOrder(getRoot());
            }
            catch(runtime_error& e) {
                cerr<<"Error: "<<e.what()<<endl;
            }
            cout<<endl;
        }

        void preOrder(Node* root) {     // Function to print the pre order traversal of the tree
            if(root != nil) {
                cout<<root->data<<" ";
                preOrder(root->left);
                preOrder(root->right);
            }
        }

        void inOrder(Node* root) {      // Function to print the in order traversal of the tree
            if (root != nil) {
                inOrder(root->left);
                cout<<root->data<<" ";
                inOrder(root->right);
            }
        }

        void postOrder(Node* root) {        // Function to print the post order traversal of the tree
            if(root != nil) {
                postOrder(root->left);
                postOrder(root->right);
                cout<<root->data<<" ";
            }
        }

        Node* getRoot() {       // Utility function that outputs the root node of the tree
            return root;
        }

    private:
        Node* root;
        Node* nil;  // Sentinel node
};

int main() {
    RBTree T;
    int construct[] = {9, 8, 5, 4, 99, 78, 31, 34, 89, 90, 21, 23, 45, 77, 88, 112, 32};     // Construction array given in problem statement
    for (int i : construct) {
        T.insert(i);
        cout<<endl;
    }
    int searching[] = {32, 56, 90};     // Searching elements given in the problem statement
    for(int i : searching) {
        try{
            T.search(T.getRoot(),i);
            cout<<"Key "<<i<<" is present in the tree."<<endl;
        }
        catch(runtime_error& e) {
            cerr<<"Error: "<<i<<e.what()<<endl;
        }
        cout<<endl;
    }
    int inserting[] = {132, 156, 11, 7};    // Elements to insert given in the problem statement
    for(int i : inserting) {
        T.insert(i);
        cout<<endl;
    }
    return 0;
}