#include <iostream>
using namespace std;

// define the XOR-linked list node
class LinkedList {
    public:
        struct Node {
            int val;
            Node *np; // XOR of next and prev
            Node(int x) {
                val = x;
                np = nullptr;
            }
        };

        LinkedList() {
            head = nullptr;     // initialize head and tail pointer to nullptr
            tail = nullptr;
        }

        ~LinkedList() {     // Clean up all nodes in the destructor
            destroy();
        }        

        Node* xorNodes(Node* a, Node* b) {      // XOR function to calculate XOR of two pointers
            return (Node*)((size_t)a ^ (size_t)b);
        }

        void printList(Node* head) {        // print the list from the given head node
            Node *prev = nullptr, *curr = head;
            Node* next;
            while (curr != nullptr) {
                cout<<curr->val<<" ";
                next = xorNodes(prev,curr->np);  // finding the next node in the list
                prev = curr;        // move prev to current and current to next node
                curr = next;
            }
            cout<<endl;
            return;
        }

        void search(int x) {        // search for a value x in the list
            Node* prev = nullptr, *curr = head;
            Node* next;
            while (curr != nullptr) {
                if (curr->val == x) {
                    cout<<"Element is present"<<endl;
                    return;
                }
                next = xorNodes(prev,curr->np);     // calculate next node
                prev = curr;
                curr = next;
            }
            cout<<"Element is not present"<<endl;
            return;
        }

        void insert(int x) {        // insert a new value x at the head
            Node* newNode = new Node(x);
            newNode->np = xorNodes(nullptr,head);
            if (head != nullptr) {
                Node *next = xorNodes(nullptr,head->np);
                head->np = xorNodes(newNode,next);      // update head's np to XOR of newNode and next
            }
            head = newNode;
            if (tail == nullptr)
                tail = head;    // if list was empty, set tail to the new node
            printList(head);
            return;
        }

        void deleteNode(int x, bool print = true) {     // delete a node with value x
            Node* prev = nullptr, *curr = head;
            Node* next;
            while (curr != nullptr) {
                if (curr->val == x) {
                    next = xorNodes(prev,curr->np);
                    if (prev != nullptr) 
                        prev->np = xorNodes(next,xorNodes(prev->np,curr));
                    else 
                        head = next;        // update head if deleted node was the head
                    if (next != nullptr)
                        next->np = xorNodes(prev,xorNodes(next->np,curr));
                    else
                        tail = prev;    // update tail if the deleted node was the last node
                    delete curr;
                    if (print)
                        printList(head);
                    return;
                }
                next = xorNodes(curr->np,prev);
                prev = curr;
                curr = next;
            }
            if(print)
                cout<<"Element is not present"<<endl;
            return;
        }

        void reverse() {        // reverse the list in O(1) time by swapping head and tail
            Node* temp = head;
            head = tail;
            tail = temp;
            printList(head);
        }

        void destroy() {        // destroy the entire list
            while (head != nullptr)
                deleteNode(head->val,false);
            return;
        }

    private:
        Node* head;
        Node* tail;
};

int main() {
    LinkedList ll;
    int k;
    cin>>k;
    while(k--) {
        int op,x;
        cin>>op;
        switch (op) {
            case 1: // search case
                cin>>x;
                ll.search(x);
                break;
            case 2: // insert case
                cin>>x;
                ll.insert(x);
                break;
            case 3: // delete case
                cin>>x;
                ll.deleteNode(x);
                break;
            case 4: // reverse case
                ll.reverse();
                break;
            default:
                break;
        }
    }
    ll.destroy(); // clean up list at the end
    return 0;
}
