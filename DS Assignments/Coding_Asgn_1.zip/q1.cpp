#include <iostream>
#include <string>
using namespace std;

class LinkedList {
    public:
        struct Node {
            int val;
            Node* next;
            Node(int x) {
                val = x;
                next = nullptr; // initialize next to nullptr
            }
        };

        LinkedList() {
            head = nullptr; // initialize head to nullptr
        }

        LinkedList(Node* other) {
            head = other; // initialize head to external_head
        }

        Node* gethead() {
            return head;
        }

        void AppendNode (int data) {
            Node* node = new Node(data);
            if(head == nullptr)
                head = node; // if list is empty, set head to new node
            else {
                auto temp_head = head;
                while(temp_head->next != nullptr) 
                    temp_head = temp_head->next; // traverse to end of list
                temp_head->next = node; // append new node at the end
            }
        }

        void display() {
            Node* temp = head;
            while (temp->next != nullptr) {
                cout<<temp->val<<", ";
                temp = temp->next;
            }
            cout<<temp->val<<endl; // print last node's value
        }

        friend void OddEvenSeparator(Node*& head); // separates odd and even indexed nodes
        
        ~LinkedList() {}

    private:
        Node* head;
};

void OddEvenSeparator(LinkedList::Node*& head) {
    if (head == nullptr || head->next == nullptr || head->next->next == nullptr)
        return; // return if list has less than 3 nodes
    LinkedList::Node* odd = head, * odd_head = head, * even = head->next, * even_head = head->next;
    while (even != nullptr && even->next != nullptr) {
        odd = odd->next = even->next; // link odd nodes
        even = even->next = even->next->next; // link even nodes
    }
    odd->next = even_head; // append even list at the end of odd list
    return;
}

int main() {
    int k;
    cin>>k;
    cin.ignore();
    while (k--) {
        LinkedList ll;
        string input;
        getline(cin, input);
        if(input=="") {
            cout<<endl;
            continue;
        }
        for (int i = 0; i<input.size(); i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;
                    i++; // handle negative numbers
                }
                while (i<input.size() && input[i] != ',') {
                    num = num * 10 + (input[i] - '0'); // accumulate digits
                    i++;
                }
                ll.AppendNode(sign * num); // append parsed number
                i--; // adjust for next loop iteration
            }
        }
        LinkedList::Node* head = ll.gethead();
        OddEvenSeparator(head); // reorder list based on odd/even indices
        ll.display(); // print the modified list
    }
    return 0;
}
