#include <iostream>
using namespace std;

class CircularLinkedList {
    public:
        struct Node {
            int val;
            Node* next;
            Node(int x) {
                val = x;
                next = nullptr;
            }
        };

        CircularLinkedList() {
            head = nullptr; // initialize head and tail
            tail = nullptr;
        }

        void AppendNode(int data) {
            Node* newNode = new Node(data);
            if (head == nullptr) { 
                head = tail = newNode;  // first node becomes head and tail
                tail->next = head;
            } 
            else {
                tail->next = newNode;
                newNode->next = head;  // maintain circular nature and update the tail
                tail = newNode;        // update tail
            }
        }

        void display() {
            if (head == nullptr) {
                cout<<"NULL"<<endl;    // empty list
                return;
            }
            Node* temp = head;
            do {
                cout<<temp->val;
                temp = temp->next;
                if (temp != head) 
                    cout<<", ";
            }while (temp != head);    // stop when back to head
            cout<<endl;
        }

        /**
         * Link the tail of the first list to the head of the second list
         * Link the tail of the second list to the head of the first list
         * Update the tail to the tail of the second list
         * Destroy the other list by setting its head and tail to nullptr
         */
        void listUnion(CircularLinkedList& cll) {
            if (head == nullptr) {  // If the first list is empty, just use the second list
                head = cll.head;
                tail = cll.tail;
            }
            else if (cll.head != nullptr) {  // Both lists are non-empty
                tail->next = cll.head;
                cll.tail->next = head;
                tail = cll.tail;
            }
            cll.head = nullptr;     // empty the second list
            cll.tail = nullptr;
        }

    private:
        Node* head;
        Node* tail;
};

int main() {
    int k;
    cin>>k;         // read number of test cases
    cin.ignore();
    while (k--) {
        CircularLinkedList cll1, cll2;
        string input;
        getline(cin, input);        
        for (int i = 0; i<input.size(); i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;      // handle negative numbers
                    i++;
                }
                while (i<input.size() && input[i] != ',') {
                    num = num * 10 + (input[i] - '0');
                    i++;
                }
                cll1.AppendNode(sign * num);     // append to first list
                i--;
            }
        }
        
        getline(cin, input);
        for (int i = 0; i<input.size(); i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;
                    i++;
                }
                while (i<input.size() && input[i] != ',') {
                    num = num * 10 + (input[i] - '0');
                    i++;
                }
                cll2.AppendNode(sign * num);
                i--;
            }
        }
        cll1.listUnion(cll2);   // merge lists and display
        cll1.display();
    }
    return 0;
}
