#include <iostream>
#include <string>
using namespace std;

class LinkedList {
    public:
        struct Node {
            int val;
            Node* next;
            Node(int x) {
                val = x;
                next = nullptr; // initialize next to nullptr
            }
        };

        LinkedList() {
            head = nullptr; // default constructor: initialize head to nullptr
        }

        LinkedList(Node* external_head) {
            head = external_head; // parameterized constructor: assign external head to list
        }

        Node* gethead() {
            return head;
        }

        void AppendNode (int data) {
            Node* node = new Node(data);
            if(head == nullptr)
                head = node; // set head if list is empty
            else {
                auto temp_head = head;
                while(temp_head->next != nullptr) 
                    temp_head = temp_head->next; // traverse to end
                temp_head->next = node; // append new node
            }
        }

        void display() {
            Node* temp = head;
            while (temp->next != nullptr) {
                cout<<temp->val<<", ";
                temp = temp->next;
            }
            cout<<temp->val<<endl; // print last node's value
        }

        friend Node* reverse(Node* head); // reverse linked list
        friend bool isPalindrome(Node* head); // check if list is palindrome
        friend Node* middleNode(Node* head); // find middle node

        ~LinkedList() {}

    private:
        Node* head;
};

LinkedList::Node* reverse(LinkedList::Node* head) {
    LinkedList::Node* prev = nullptr;
    LinkedList::Node* curr = head;
    LinkedList::Node* next = nullptr;
    while(curr != nullptr) {
        next = curr->next;
        curr->next = prev; // reverse links
        prev = curr;
        curr = next;
    }
    return prev; // return new head (reversed list)
}

bool isPalindrome(LinkedList::Node* head) {
    if(head == nullptr || head->next == nullptr)
        return true; // return true for empty or single node list
    LinkedList::Node* mid = middleNode(head);
    LinkedList::Node* half = reverse(mid); // reverse second half
    LinkedList::Node* start = head;
    LinkedList::Node* temp = half;
    while(temp != nullptr) {
        if(start->val != temp->val) { // compare halves
            reverse(half); // restore list before returning
            return false;
        }
        start = start->next;
        temp = temp->next;
    }
    reverse(half); // restore list after comparison
    return true;
}

LinkedList::Node* middleNode(LinkedList::Node* head) {
    LinkedList::Node* slow = head;
    LinkedList::Node* fast = head;
    while(fast != nullptr && fast->next != nullptr) {
        slow = slow->next; // move slow one step
        fast = fast->next->next; // move fast two steps
    }
    return slow; // return middle node
}

int main() {
    int k;
    cin>>k;
    cin.ignore();
    while (k--) {
        LinkedList ll;
        string input;
        string output;
        getline(cin, input);
        if(input=="\0") {
            cout<<"True"<<endl; // empty input is treated as palindrome
            continue;
        }
        for (int i = 0; input[i]!='\0'; i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;
                    i++;
                }
                while (input[i]!='\0' && input[i] != ',') {
                    num = num * 10 + (input[i] - '0'); // parse number
                    i++;
                }
                ll.AppendNode(sign * num); // append parsed number
                i--;
            }
        }
        LinkedList::Node* head = ll.gethead();
        output = (isPalindrome(head) == 1? "True" : "False");
        cout<<output<<endl;
    }
    return 0;
}