#include <iostream>
using namespace std;

class LinkedList {
    public:
        struct Node {
            int val;
            Node* next;
            Node(int x) {
                val = x;
                next = nullptr;
            }
        };

        LinkedList() : head(nullptr) {}

        void AppendNode(int data) {
            Node* newNode = new Node(data);
            newNode->next = head;  // insert the new node at the head, since we are sorting the list later, this won't matter
            head = newNode;
        }

        void sortList() {   // sort the list using Merge Sort
            head = mergeSort(head);
        }

        void display() {    // display the list
            Node* temp = head;
            if (temp==nullptr) {
                cout<<"NULL"<<endl;
                return;
            }
            while (temp != nullptr) {
                cout<<temp->val;
                if (temp->next != nullptr) cout << ", ";
                temp = temp->next;
            }
            cout << endl;
        }

        LinkedList intersection(LinkedList& other) {   // intersection of two sorted linked lists
            LinkedList result;
            Node* temp1 = head;
            Node* temp2 = other.head;
            while (temp1 != nullptr && temp2 != nullptr) {
                if (temp1->val == temp2->val) {
                    result.AppendNode(temp1->val); // add the common element to the result set
                    temp1 = temp1->next;
                    temp2 = temp2->next;
                } 
                else if (temp1->val < temp2->val)
                    temp1 = temp1->next;
                else
                    temp2 = temp2->next;
            }
            return result;  // the result set will be sorted, but in reverse order
        }

    private:
        Node* head;

        Node* merge(Node* left, Node* right) {  // merge two sorted linked lists
            if (!left) 
                return right;
            if (!right) 
                return left;
            if (left->val < right->val) {
                left->next = merge(left->next, right);
                return left;
            } 
            else {
                right->next = merge(left, right->next);
                return right;
            }
        }

        Node* mergeSort(Node* head) {   // merge sort for linked lists
            if (!head || !head->next) 
                return head;
            Node* middle = getMiddle(head);    // split the list into two halves
            Node* nextToMiddle = middle->next;
            middle->next = nullptr;
            Node* left = mergeSort(head);    // recursively sort both halves
            Node* right = mergeSort(nextToMiddle);
            return merge(left, right);  // merge the sorted halves
        }

        Node* getMiddle(Node* head) {   // find the middle of the linked list (slow and fast pointer technique)
            if (head == nullptr) 
                return head;
            Node* slow = head;
            Node* fast = head->next;
            while (fast != nullptr && fast->next != nullptr) {
                slow = slow->next;
                fast = fast->next->next;
            }
            return slow;
        }
};

int main() {
    int k; // Number of test cases
    cin>>k;
    cin.ignore();
    while(k--) {
        LinkedList ll1, ll2;
        string input;
        getline(cin, input); 
        for (int i = 0; input[i]!='\0'; i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;      // handle negative numbers
                    i++;
                }
                while (input[i]!='\0' && input[i] != ',') {
                    num = num * 10 + (input[i] - '0');
                    i++;
                }
                ll1.AppendNode(sign * num);    // append to the start of the first list
                i--;
            }
        }

        getline(cin, input);
        for (int i = 0; input[i]!='\0'; i++) {
            if (input[i] != ',' && input[i] != ' ') {
                int sign = 1, num = 0;
                if (input[i] == '-') {
                    sign = -1;
                    i++;
                }
                while (input[i]!='\0' && input[i] != ',') {
                    num = num * 10 + (input[i] - '0');
                    i++;
                }
                ll2.AppendNode(sign * num);
                i--;
            }
        }
        ll1.sortList();
        ll2.sortList();
        LinkedList result = ll1.intersection(ll2); // find intersection of the lists and then display
        result.display();
    }
    return 0;
}