#include <iostream>
#include <string>
using namespace std;

class Stack {
    private:
        char s[1000];
        int top, count;
        
    public:
        Stack(); // default constructor
        void push(char x);
        char pop();
        char peek();
        int size();
};

Stack::Stack() {
    top = -1; // initialize top to -1 (empty stack)
    count = 0; // initialize count to 0
}

void Stack::push(char x) {
    if (top == 999) {
        cout<<"Stack is full"<<endl; // handle stack overflow
        return;
    }
    if (top == -1)
        top = 0; // set top to 0 if stack is empty
    else    
        top++;
    s[top] = x;
    count++;
}

char Stack::pop() {
    if (top == -1) {
        cout<<"Stack is Empty"<<endl; // handle stack underflow
        return '\0';
    }
    char x = s[top];
    top--;
    count--;
    return x;
}

char Stack::peek() {
    if (top == -1) {
        cout<<"Stack is Empty"<<endl; // handle empty stack
        return '\0';
    }
    char x = s[top];
    return x;
}

int Stack::size() {
    return count; // return number of elements
}

int isOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '(' || c == ')')
        return 1; // return 1 if operator
    return 0; // not an operator
}

int precedence(char op) {
    if(op == '^')
        return 3; // highest precedence
    else if(op == '*' || op == '/')
        return 2; // medium precedence
    else if(op == '+' || op == '-')
        return 1; // lowest precedence
    return 0; // no precedence
}

string convert(string infix) {
    Stack S;
    string postfix;
    for (char c : infix) {
        if (!isOperator(c)) 
            postfix += c; // add operand to postfix
        else if (c == '(')
            S.push(c); // push '(' to stack
        else if (c == ')') {
            while (S.size() != 0 && S.peek() != '(') 
                postfix += S.pop(); // pop until '('
            S.pop(); // pop '('
        } 
        else {
            while (S.size() != 0 && precedence(S.peek()) >= precedence(c))
                postfix += S.pop(); // pop operators with higher or equal precedence
            S.push(c); // push current operator
        }
    }
    while (S.size() > 0)
        postfix += S.pop(); // pop remaining operators
    return postfix;
}

int main() {
    int k;
    cin>>k; // read number of test cases
    cin.ignore();
    while(k--) {
        string infix;
        getline(cin, infix); // read infix expression
        string postfix = convert(infix); // convert infix to postfix
        cout<<postfix<<endl; // output postfix expression
    }
    return 0;
}
